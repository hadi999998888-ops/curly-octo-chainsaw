package com.loophack.app

import android.content.Context
import android.text.TextUtils
import android.view.View

/** Блок «Фоновая музыка»: трек, старт/пауза, громкость, повтор. */
object MusicPanel {

    fun build(ctx: Context, onPick: () -> Unit): View {
        fun dp(v: Int) = Ui.dp(ctx, v)

        val card = Ui.card(ctx)
        card.addView(Ui.sectionTitle(ctx, "ФОНОВАЯ МУЗЫКА"))

        val name = Repo.musicName(ctx)
        val track = Ui.text(
            ctx,
            if (name.isEmpty()) "Трек не выбран" else "♪  $name",
            13f,
            if (name.isEmpty()) Ui.GRAY else Ui.WHITE,
            true
        )
        track.maxLines = 1
        track.ellipsize = TextUtils.TruncateAt.END
        card.addView(track, Ui.lin(Ui.MATCH, Ui.WRAP, 0f, 0, dp(8), 0, 0))

        var playing = Repo.musicPlay(ctx)
        val play = Ui.chip(ctx, if (playing) "⏸ Пауза" else "▶ Играть", playing) { }
        play.setOnClickListener {
            if (Repo.musicUri(ctx).isEmpty()) {
                Ui.toast(ctx, "Сначала выберите трек")
                return@setOnClickListener
            }
            if (!OverlayService.running) {
                Ui.toast(ctx, "Сначала нажмите СТАРТ")
                return@setOnClickListener
            }
            playing = !playing
            Repo.setMusicPlay(ctx, playing)
            OverlayService.musicSync()
            play.text = if (playing) "⏸ Пауза" else "▶ Играть"
            Ui.styleChip(play, playing)
        }
        card.addView(
            Ui.row(ctx, play, Ui.chip(ctx, "♫ Выбрать трек") { onPick() }),
            Ui.lin(Ui.MATCH, Ui.WRAP, 0f, 0, dp(8), 0, 0)
        )

        card.addView(
            Ui.seek(ctx, "Громкость", 0, 100, Repo.musicVol(ctx), { "$it%" }) { v ->
                Repo.setMusicVol(ctx, v)
                OverlayService.musicSync()
            }
        )

        val loop = Ui.chip(ctx, "🔁 Повтор трека", Repo.musicLoop(ctx)) { }
        loop.setOnClickListener {
            val n = !Repo.musicLoop(ctx)
            Repo.setMusicLoop(ctx, n)
            Ui.styleChip(loop, n)
            OverlayService.musicSync()
        }
        card.addView(loop, Ui.lin(Ui.WRAP, Ui.WRAP, 0f, 0, dp(4), 0, 0))
        return card
    }
}
