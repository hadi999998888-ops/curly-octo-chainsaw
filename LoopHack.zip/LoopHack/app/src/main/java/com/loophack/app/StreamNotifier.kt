package com.loophack.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Outline
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.AccelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import kotlin.math.min

/** Круглая аватарка отправителя уведомления: выбранное фото или логотип LOOP HACK. */
object Avatar {
    private var cacheKey = ""
    private var cacheBmp: Bitmap? = null

    fun make(ctx: Context): ImageView {
        val iv = ImageView(ctx)
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        val uri = Repo.notifyAvatar(ctx)
        var bmp: Bitmap? = null
        if (uri.isNotEmpty()) {
            if (uri == cacheKey && cacheBmp != null) {
                bmp = cacheBmp
            } else {
                bmp = ItemViews.decodeBitmap(ctx, Uri.parse(uri))
                cacheKey = uri
                cacheBmp = bmp
            }
        }
        if (bmp != null) iv.setImageBitmap(bmp) else iv.setImageResource(R.drawable.logo)
        iv.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setOval(0, 0, view.width, view.height)
            }
        }
        iv.clipToOutline = true
        return iv
    }
}

/**
 * Показывает «как будто пришло уведомление» сверху экрана: плавно выезжает,
 * держится несколько секунд и уезжает. Повторяется каждые N секунд, пока включено.
 */
class StreamNotifier(private val ctx: Context, private val wm: WindowManager) {

    private val ui = Handler(Looper.getMainLooper())
    private var running = false
    private var lastInterval = 0
    private var banner: FrameLayout? = null
    private var bannerCard: View? = null

    private fun d(v: Int) = Ui.dp(ctx, v)

    private val hideTask = Runnable { animateOut() }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            show()
            ui.postDelayed(this, Repo.notifyInterval(ctx) * 1000L)
        }
    }

    /** Перечитать настройки: включить, выключить или поменять интервал. */
    fun apply() {
        val on = Repo.notifyEnabled(ctx)
        val interval = Repo.notifyInterval(ctx)
        if (on && !running) {
            running = true
            lastInterval = interval
            ui.removeCallbacks(tick)
            ui.postDelayed(tick, 1500)
        } else if (!on && running) {
            running = false
            ui.removeCallbacks(tick)
            hideNow()
        } else if (on && interval != lastInterval) {
            lastInterval = interval
            ui.removeCallbacks(tick)
            ui.postDelayed(tick, interval * 1000L)
        }
    }

    /** Показать один раз прямо сейчас (для проверки). */
    fun preview() {
        show()
    }

    fun destroy() {
        running = false
        ui.removeCallbacks(tick)
        hideNow()
    }

    private fun buildCard(): LinearLayout {
        val card = LinearLayout(ctx)
        card.orientation = LinearLayout.HORIZONTAL
        card.gravity = Gravity.CENTER_VERTICAL
        card.setPadding(d(12), d(10), d(16), d(10))
        card.background = GradientDrawable().apply {
            setColor(0xF2150E1E.toInt())
            cornerRadius = d(22).toFloat()
            setStroke(d(1), 0x66FFFFFF)
        }

        val avatar = Avatar.make(ctx)
        avatar.scaleX = 0.5f
        avatar.scaleY = 0.5f
        card.addView(avatar, Ui.lin(d(44), d(44), 0f, 0, 0, d(12), 0))

        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        val top = LinearLayout(ctx)
        top.orientation = LinearLayout.HORIZONTAL
        val name = Ui.text(ctx, Repo.notifyName(ctx), 14f, Ui.WHITE, true)
        name.maxLines = 1
        name.ellipsize = TextUtils.TruncateAt.END
        top.addView(name, Ui.lin(0, Ui.WRAP, 1f))
        top.addView(Ui.text(ctx, "сейчас", 11f, Ui.GRAY))
        val msg = Ui.text(ctx, Repo.notifyText(ctx), 14f, 0xFFE9DFF5.toInt())
        msg.maxLines = 2
        msg.ellipsize = TextUtils.TruncateAt.END
        col.addView(top, Ui.lin(Ui.MATCH, Ui.WRAP))
        col.addView(msg, Ui.lin(Ui.MATCH, Ui.WRAP, 0f, 0, d(2), 0, 0))
        card.addView(col, Ui.lin(0, Ui.WRAP, 1f))

        card.translationY = -d(170).toFloat()
        card.alpha = 0f
        return card
    }

    private fun show() {
        hideNow()
        val card = buildCard()
        val root = FrameLayout(ctx)
        root.setPadding(0, d(34), 0, d(8))
        root.addView(card, FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP))

        val w = min(Screen.w(ctx) - d(20), d(460))
        val lp = WindowManager.LayoutParams(
            w, Ui.WRAP,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        try {
            wm.addView(root, lp)
        } catch (e: Exception) {
            return
        }
        banner = root
        bannerCard = card

        card.animate()
            .translationY(0f)
            .alpha(1f)
            .setDuration(440)
            .setInterpolator(OvershootInterpolator(0.9f))
            .start()
        val avatar = (card.getChildAt(0))
        avatar.animate()
            .scaleX(1f)
            .scaleY(1f)
            .setStartDelay(200)
            .setDuration(340)
            .setInterpolator(OvershootInterpolator(2.2f))
            .start()
        ui.postDelayed(hideTask, 4800)
    }

    private fun animateOut() {
        val card = bannerCard ?: return
        val root = banner ?: return
        card.animate()
            .translationY(-d(170).toFloat())
            .alpha(0f)
            .setDuration(320)
            .setInterpolator(AccelerateInterpolator())
            .withEndAction {
                if (banner === root) {
                    try {
                        wm.removeView(root)
                    } catch (e: Exception) {
                    }
                    banner = null
                    bannerCard = null
                }
            }
            .start()
    }

    private fun hideNow() {
        ui.removeCallbacks(hideTask)
        bannerCard?.animate()?.cancel()
        banner?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
            }
        }
        banner = null
        bannerCard = null
    }
}
