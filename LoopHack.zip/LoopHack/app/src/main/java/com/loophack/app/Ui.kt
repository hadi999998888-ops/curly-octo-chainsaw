package com.loophack.app

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.text.Editable
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

/** Небольшой набор помощников для построения интерфейса из кода. */
object Ui {
    val BLACK = 0xFF000000.toInt()
    val PANEL = 0xFF121212.toInt()
    val PANEL2 = 0xFF1E1E1E.toInt()
    val VIOLET = 0xFFBDBDBD.toInt()
    val PINK = 0xFFFFFFFF.toInt()
    val WHITE = 0xFFFFFFFF.toInt()
    val GRAY = 0xFF9E9E9E.toInt()
    val DANGER = 0xFF8E1B1B.toInt()

    const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    val palette = intArrayOf(
        0xFFFFFFFF.toInt(), 0xFF000000.toInt(), 0xFFFF2DAA.toInt(), 0xFF8A2BE2.toInt(),
        0xFF00E5FF.toInt(), 0xFF39FF14.toInt(), 0xFFFFE600.toInt(), 0xFFFF7A00.toInt(),
        0xFFFF1744.toInt(), 0xFF2979FF.toInt(), 0xFFFF00E5.toInt(), 0xFF9E9E9E.toInt()
    )

    fun dp(c: Context, v: Float): Int = (v * c.resources.displayMetrics.density + 0.5f).toInt()
    fun dp(c: Context, v: Int): Int = dp(c, v.toFloat())

    fun lin(w: Int, h: Int, weight: Float = 0f, l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0) =
        LinearLayout.LayoutParams(w, h, weight).apply { setMargins(l, t, r, b) }

    fun rounded(color: Int, radius: Float, strokeColor: Int = 0, strokeW: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius
            if (strokeW > 0) setStroke(strokeW, strokeColor)
        }

    /** Основной (белый) фон кнопок. */
    fun gradient(radius: Float): GradientDrawable =
        GradientDrawable().apply {
            setColor(WHITE)
            cornerRadius = radius
        }

    private fun ripple(bg: Drawable): Drawable =
        RippleDrawable(ColorStateList.valueOf(0x55808080), bg, null)

    fun text(c: Context, s: String, size: Float = 14f, color: Int = WHITE, bold: Boolean = false): TextView =
        TextView(c).apply {
            text = s
            setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    /** style: 0 — градиентная основная, 1 — вторичная, 2 — опасная. */
    fun button(c: Context, label: String, style: Int = 0, onClick: () -> Unit): TextView {
        val t = text(c, label, 14f, if (style == 0) BLACK else WHITE, true)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(c, 12), dp(c, 13), dp(c, 12), dp(c, 13))
        val r = dp(c, 14).toFloat()
        val bg: Drawable = when (style) {
            0 -> gradient(r)
            1 -> rounded(PANEL2, r, 0x44FFFFFF, dp(c, 1))
            else -> rounded(DANGER, r)
        }
        t.background = ripple(bg)
        t.isClickable = true
        t.setOnClickListener { onClick() }
        return t
    }

    /** Меняет вид кнопки-чипа: выделена (градиент) или обычная. */
    fun styleChip(t: TextView, active: Boolean) {
        val r = dp(t.context, 10).toFloat()
        val bg: Drawable = if (active) gradient(r) else rounded(PANEL2, r, 0x33FFFFFF, dp(t.context, 1))
        t.background = ripple(bg)
        t.setTextColor(if (active) BLACK else WHITE)
    }

    fun chip(c: Context, label: String, active: Boolean = false, onClick: () -> Unit): TextView {
        val t = text(c, label, 12f, WHITE, true)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(c, 10), dp(c, 8), dp(c, 10), dp(c, 8))
        styleChip(t, active)
        t.isClickable = true
        t.setOnClickListener { onClick() }
        return t
    }

    fun toast(c: Context, s: String) = Toast.makeText(c, s, Toast.LENGTH_SHORT).show()

    /** Поле ввода в стиле приложения. */
    fun field(c: Context, hint: String, value: String, multiline: Boolean = false): EditText {
        val e = EditText(c)
        e.setText(value)
        e.hint = hint
        e.setTextColor(WHITE)
        e.setHintTextColor(GRAY)
        e.textSize = 15f
        if (multiline) {
            e.minLines = 2
            e.maxLines = 5
            e.gravity = Gravity.TOP or Gravity.START
        } else {
            e.setSingleLine(true)
            e.imeOptions = EditorInfo.IME_ACTION_DONE
        }
        e.background = rounded(PANEL2, dp(c, 12).toFloat(), 0x33FFFFFF, dp(c, 1))
        e.setPadding(dp(c, 12), dp(c, 10), dp(c, 12), dp(c, 10))
        return e
    }

    /** Вызывает block при каждом изменении текста в поле. */
    fun watch(e: EditText, block: (String) -> Unit) {
        e.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                block(s?.toString() ?: "")
            }
        })
    }

    /** Плавное появление блоков по очереди (снизу вверх + проявление). */
    fun reveal(vararg views: View) {
        views.forEachIndexed { i, v ->
            v.alpha = 0f
            v.translationY = dp(v.context, 22).toFloat()
            v.animate()
                .alpha(1f)
                .translationY(0f)
                .setStartDelay(i * 60L)
                .setDuration(360)
                .setInterpolator(DecelerateInterpolator())
                .start()
        }
    }

    /** Ряд из равных по ширине элементов. */
    fun row(c: Context, vararg v: View): LinearLayout {
        val r = LinearLayout(c)
        r.orientation = LinearLayout.HORIZONTAL
        v.forEachIndexed { i, x ->
            r.addView(x, lin(0, WRAP, 1f, if (i == 0) 0 else dp(c, 6), 0, 0, 0))
        }
        return r
    }

    /** Карточка-контейнер в стиле приложения. */
    fun card(c: Context): LinearLayout = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(PANEL, dp(c, 18).toFloat(), 0x33FFFFFF, dp(c, 1))
        setPadding(dp(c, 14), dp(c, 12), dp(c, 14), dp(c, 14))
    }

    fun sectionTitle(c: Context, s: String): TextView =
        text(c, s, 12f, GRAY, true).apply { letterSpacing = 0.1f }

    /** Скруглённый логотип; размер задаёт вызывающий через LayoutParams. */
    fun logo(c: Context, radius: Int): ImageView {
        val iv = ImageView(c)
        iv.setImageResource(R.drawable.logo)
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        iv.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, dp(c, radius).toFloat())
            }
        }
        iv.clipToOutline = true
        return iv
    }

    /** Сворачиваемая карточка с заголовком и текстом. */
    fun expandable(c: Context, title: String, body: String): LinearLayout {
        val box = card(c)
        val head = LinearLayout(c)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val arrow = text(c, "▼", 12f, PINK, true)
        head.addView(text(c, title, 14f, WHITE, true), lin(0, WRAP, 1f))
        head.addView(arrow)
        val b = text(c, body, 13f, GRAY)
        b.setLineSpacing(0f, 1.15f)
        b.setPadding(0, dp(c, 10), 0, 0)
        b.visibility = View.GONE
        head.setOnClickListener {
            val show = b.visibility != View.VISIBLE
            b.visibility = if (show) View.VISIBLE else View.GONE
            arrow.text = if (show) "▲" else "▼"
        }
        box.addView(head)
        box.addView(b)
        return box
    }

    fun seek(
        c: Context,
        title: String,
        lo: Int,
        hi: Int,
        value: Int,
        fmt: (Int) -> String = { it.toString() },
        onChange: (Int) -> Unit
    ): LinearLayout {
        val box = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(c, 4), 0, dp(c, 4))
        }
        val label = text(c, "$title: ${fmt(value)}", 13f, GRAY)
        val bar = SeekBar(c)
        bar.max = hi - lo
        bar.progress = (value - lo).coerceIn(0, hi - lo)
        bar.progressTintList = ColorStateList.valueOf(PINK)
        bar.thumbTintList = ColorStateList.valueOf(PINK)
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = p + lo
                label.text = "$title: ${fmt(v)}"
                if (fromUser) onChange(v)
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(label)
        box.addView(bar, lin(MATCH, WRAP))
        return box
    }

    fun toggle(c: Context, title: String, checked: Boolean, onChange: (Boolean) -> Unit): Switch =
        Switch(c).apply {
            text = title
            setTextColor(WHITE)
            isChecked = checked
            setPadding(0, dp(c, 8), 0, dp(c, 8))
            setOnCheckedChangeListener { _, b -> onChange(b) }
        }

    /**
     * Строка выбора цвета: палитра + ввод HEX прямо в строке (без диалогов,
     * поэтому работает и внутри оверлея). attachInput подключает клавиатуру в оверлее.
     */
    fun colorRow(
        c: Context,
        title: String,
        current: Int,
        attachInput: (EditText) -> Unit = {},
        onPick: (Int) -> Unit
    ): LinearLayout {
        val box = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(c, 6), 0, dp(c, 6))
        }
        box.addView(text(c, title, 13f, GRAY))
        val scroll = HorizontalScrollView(c).apply { isHorizontalScrollBarEnabled = false }
        val row = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        scroll.addView(row)
        box.addView(scroll, lin(MATCH, WRAP, 0f, 0, dp(c, 6), 0, 0))

        val hex = field(c, "HEX, например FF2DAA", "")
        hex.visibility = View.GONE
        attachInput(hex)
        box.addView(hex, lin(MATCH, WRAP, 0f, 0, dp(c, 6), 0, 0))

        var cur = current

        fun fill() {
            row.removeAllViews()
            for (col in palette) {
                val sel = col == cur
                val v = View(c)
                v.background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(col)
                    setStroke(if (sel) dp(c, 3) else dp(c, 1), if (sel) WHITE else 0x66FFFFFF)
                }
                v.setOnClickListener {
                    cur = col
                    onPick(col)
                    fill()
                }
                row.addView(v, lin(dp(c, 34), dp(c, 34), 0f, 0, 0, dp(c, 10), 0))
            }
            row.addView(
                chip(c, "HEX", hex.visibility == View.VISIBLE) {
                    hex.visibility = if (hex.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                    fill()
                },
                lin(WRAP, dp(c, 34))
            )
        }

        watch(hex) { s ->
            val raw = s.trim().removePrefix("#")
            val valid = (raw.length == 6 || raw.length == 8) &&
                    raw.all { ch -> ch.isDigit() || ch.lowercaseChar() in 'a'..'f' }
            if (valid) {
                cur = Color.parseColor("#$raw")
                onPick(cur)
                fill()
            }
        }
        fill()
        return box
    }
}
