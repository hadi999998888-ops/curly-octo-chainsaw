package com.loophack.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri

object Links {
    const val TELEGRAM = "https://t.me/ExtraCheatStanddof2"

    /** Просто открывает ссылку: Telegram, если установлен, иначе браузер. Возвращает true, если открылось. */
    fun openTelegram(c: Context): Boolean {
        return try {
            c.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(TELEGRAM)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            true
        } catch (e: Exception) {
            Ui.toast(c, "Не удалось открыть ссылку")
            false
        }
    }

    /** after вызывается только если ссылка действительно открылась. */
    fun telegramButton(c: Context, after: () -> Unit = {}) =
        Ui.button(c, "✈  НАШ TELEGRAM-КАНАЛ", 0) {
            if (openTelegram(c)) after()
        }
}

/** Запуск вспомогательных экранов и из приложения, и из оверлея (сервис). */
object Nav {
    fun openEditor(c: Context, id: String?) {
        val i = Intent(c, EditorActivity::class.java)
        if (id != null) i.putExtra("id", id)
        if (c !is Activity) i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        c.startActivity(i)
    }

    /** Прозрачный экран, который один раз запрашивает доступ к фото, видео и музыке. */
    fun requestMedia(c: Context) {
        val i = Intent(c, PickerActivity::class.java).putExtra("type", "perm")
        if (c !is Activity) i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        c.startActivity(i)
    }

    fun pickMedia(c: Context, type: String) {
        val i = Intent(c, PickerActivity::class.java).putExtra("type", type)
        if (c !is Activity) i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        c.startActivity(i)
    }
}

object Help {
    const val INSTRUCTION =
        "1. Нажмите «СТАРТ» и выдайте разрешение «Поверх других приложений».\n\n" +
                "2. У самого нижнего края экрана появится тонкая стрелка. Зажмите её и проведите вверх — " +
                "откроется меню. Стрелку можно сдвинуть влево или вправо, а её высоту и заметность " +
                "настроить в разделе «Ещё».\n\n" +
                "3. Всё настраивается прямо в меню, из игры вас никуда не выкидывает: " +
                "фото, видео и музыка выбираются во встроенной галерее (доступ к медиа нужно разрешить один раз), " +
                "текст редактируется тут же, а результат виден на экране сразу.\n\n" +
                "4. Элемент двигается одним пальцем, масштабируется и вращается двумя.\n\n" +
                "5. «Закрепить» фиксирует элемент. Прозрачность остаётся такой, как вы её задали.\n\n" +
                "6. Музыка: выберите трек, затем «Играть» или «Пауза», ползунком меняется громкость. " +
                "Она играет поверх игры и не глушит её.\n\n" +
                "7. В горизонтальном режиме меню превращается в боковую панель справа.\n\n" +
                "8. Кнопка «—» убирает меню вниз. Чтобы вернуть, снова зажмите стрелку и проведите вверх.\n\n" +
                "9. Начните стрим с демонстрацией экрана — все элементы видны поверх."
}
