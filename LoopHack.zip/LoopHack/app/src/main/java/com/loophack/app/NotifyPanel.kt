package com.loophack.app

import android.content.Context
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout

/**
 * Блок «Уведомление для стримов»: включение, ник, текст, аватарка, интервал.
 * Работает и в приложении, и внутри оверлея (attachInput подключает клавиатуру).
 */
object NotifyPanel {

    fun build(ctx: Context, attachInput: (EditText) -> Unit, onPickAvatar: () -> Unit): View {
        fun dp(v: Int) = Ui.dp(ctx, v)

        val card = Ui.card(ctx)

        val caption = Ui.text(ctx, "", 12f, Ui.GRAY)
        fun refreshCaption() {
            caption.text = "Каждые ${Repo.notifyInterval(ctx)} сек сверху приходит уведомление"
        }
        refreshCaption()

        card.addView(
            Ui.toggle(ctx, "Уведомление для стримов", Repo.notifyEnabled(ctx)) { on ->
                Repo.setNotifyEnabled(ctx, on)
                OverlayService.refreshNotifier()
                if (on && !OverlayService.running) {
                    Ui.toast(ctx, "Заработает после нажатия СТАРТ")
                }
            }
        )
        card.addView(caption)

        // Отправитель: аватарка + ник + текст
        val sender = LinearLayout(ctx)
        sender.orientation = LinearLayout.HORIZONTAL
        sender.gravity = Gravity.CENTER_VERTICAL
        val avatarHolder = FrameLayout(ctx)
        fun refreshAvatar() {
            avatarHolder.removeAllViews()
            avatarHolder.addView(Avatar.make(ctx), FrameLayout.LayoutParams(dp(52), dp(52)))
        }
        refreshAvatar()
        sender.addView(avatarHolder, Ui.lin(dp(52), dp(52), 0f, 0, 0, dp(10), 0))
        val fields = LinearLayout(ctx)
        fields.orientation = LinearLayout.VERTICAL
        val nameEt = Ui.field(ctx, "Ник отправителя", Repo.notifyName(ctx))
        attachInput(nameEt)
        Ui.watch(nameEt) { s ->
            if (s.isNotBlank()) Repo.setNotifyName(ctx, s.trim())
        }
        val textEt = Ui.field(ctx, "Текст уведомления", Repo.notifyText(ctx))
        attachInput(textEt)
        Ui.watch(textEt) { s ->
            if (s.isNotBlank()) Repo.setNotifyText(ctx, s.trim())
        }
        fields.addView(nameEt, Ui.lin(Ui.MATCH, Ui.WRAP))
        fields.addView(textEt, Ui.lin(Ui.MATCH, Ui.WRAP, 0f, 0, dp(6), 0, 0))
        sender.addView(fields, Ui.lin(0, Ui.WRAP, 1f))
        card.addView(sender, Ui.lin(Ui.MATCH, Ui.WRAP, 0f, 0, dp(10), 0, 0))

        card.addView(
            Ui.row(
                ctx,
                Ui.chip(ctx, "Выбрать аватар") { onPickAvatar() },
                Ui.chip(ctx, "Вернуть логотип") {
                    Repo.setNotifyAvatar(ctx, "")
                    refreshAvatar()
                }
            ),
            Ui.lin(Ui.MATCH, Ui.WRAP, 0f, 0, dp(8), 0, 0)
        )

        card.addView(
            Ui.seek(ctx, "Интервал", 8, 120, Repo.notifyInterval(ctx), { "$it сек" }) { v ->
                Repo.setNotifyInterval(ctx, v)
                refreshCaption()
                OverlayService.refreshNotifier()
            }
        )

        card.addView(
            Ui.chip(ctx, "▶ Показать пример") {
                if (OverlayService.running) OverlayService.previewNotify()
                else Ui.toast(ctx, "Сначала нажмите СТАРТ")
            },
            Ui.lin(Ui.MATCH, Ui.WRAP, 0f, 0, dp(6), 0, 0)
        )
        return card
    }
}
