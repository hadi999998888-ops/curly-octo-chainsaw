package com.loophack.app

import android.content.Context
import android.util.DisplayMetrics
import android.view.WindowManager

/** Реальный размер экрана (вместе с системными панелями) в текущей ориентации. */
object Screen {
    @Suppress("DEPRECATION")
    private fun metrics(c: Context): DisplayMetrics {
        val dm = DisplayMetrics()
        val wm = c.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        wm.defaultDisplay.getRealMetrics(dm)
        return dm
    }

    fun w(c: Context): Int = metrics(c).widthPixels

    fun h(c: Context): Int = metrics(c).heightPixels
}
