package com.loophack.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.ExifInterface
import android.net.Uri
import android.util.TypedValue
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.TextView

/** TextView с настоящей обводкой текста. */
class StrokeTextView(c: Context) : TextView(c) {
    var strokeW = 0f
    var strokeC = 0

    override fun onDraw(canvas: Canvas) {
        val l = layout
        if (strokeW > 0f && l != null) {
            val p = paint
            val oldStyle = p.style
            val oldWidth = p.strokeWidth
            val oldColor = p.color
            p.style = Paint.Style.STROKE
            p.strokeWidth = strokeW * 2f
            p.strokeJoin = Paint.Join.ROUND
            p.color = strokeC
            canvas.save()
            canvas.translate(compoundPaddingLeft.toFloat(), extendedPaddingTop.toFloat())
            l.draw(canvas)
            canvas.restore()
            p.style = oldStyle
            p.strokeWidth = oldWidth
            p.color = oldColor
        }
        super.onDraw(canvas)
    }
}

object ItemViews {
    val fontNames = listOf("Обычный", "Serif", "Mono", "Рукопись", "Casual", "Узкий", "Black")
    private val families = listOf(
        "sans-serif", "serif", "monospace", "cursive", "casual",
        "sans-serif-condensed", "sans-serif-black"
    )

    fun typeface(idx: Int, bold: Boolean): Typeface =
        Typeface.create(
            Typeface.create(families[idx.coerceIn(0, families.lastIndex)], Typeface.NORMAL),
            if (bold) Typeface.BOLD else Typeface.NORMAL
        )

    /** Собирает вид текстового элемента. scale — множитель размера (жест масштабирования). */
    fun makeText(ctx: Context, item: Item, scale: Float): FrameLayout {
        val d = ctx.resources.displayMetrics.density
        val sc = scale.coerceAtLeast(0.05f)
        val tv = StrokeTextView(ctx)
        tv.text = item.text.ifEmpty { " " }
        tv.setTextSize(TypedValue.COMPLEX_UNIT_PX, item.textSize * d * sc)
        tv.setTextColor(item.textColor)
        tv.typeface = typeface(item.font, item.bold)
        tv.gravity = Gravity.CENTER
        tv.setPadding(
            (item.padH * d * sc).toInt(), (item.padV * d * sc).toInt(),
            (item.padH * d * sc).toInt(), (item.padV * d * sc).toInt()
        )
        if (item.bgEnabled) {
            tv.background = GradientDrawable().apply {
                setColor(item.bgColor)
                cornerRadius = 12f * d * sc
            }
        }
        if (item.glow > 0f) {
            tv.setShadowLayer(item.glow * d * sc, 0f, 0f, item.glowColor)
        }
        tv.strokeW = item.strokeWidth * d * sc
        tv.strokeC = item.strokeColor

        val room = ((item.glow + item.strokeWidth) * d * sc).toInt() + 2
        val box = FrameLayout(ctx)
        box.clipChildren = false
        box.clipToPadding = false
        box.setPadding(room, room, room, room)
        box.addView(tv, FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP))
        return box
    }

    /** Декодирует картинку с ограничением размера и поворотом по EXIF. */
    fun decodeBitmap(ctx: Context, uri: Uri): Bitmap? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / sample > 1600 || bounds.outHeight / sample > 1600) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            var bmp = ctx.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, opts)
            }
            val orientation = try {
                ctx.contentResolver.openInputStream(uri)?.use {
                    ExifInterface(it).getAttributeInt(
                        ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
                    )
                } ?: ExifInterface.ORIENTATION_NORMAL
            } catch (e: Exception) {
                ExifInterface.ORIENTATION_NORMAL
            }
            val deg = when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            if (bmp != null && deg != 0f) {
                val m = Matrix()
                m.postRotate(deg)
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }
            bmp
        } catch (e: Throwable) {
            null
        }
    }
}
