package com.loophack.app

import android.content.Context
import android.graphics.SurfaceTexture
import android.media.MediaPlayer
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.Surface
import android.view.TextureView

/** Видео внутри оверлея: TextureView + MediaPlayer (поддерживает масштаб и поворот). */
class VideoLayer(context: Context) : TextureView(context), TextureView.SurfaceTextureListener {
    var uri: Uri? = null

    private var player: MediaPlayer? = null
    private var surface: Surface? = null
    private var prepared = false
    private var ended = false
    private var playing = true
    private var loop = true
    private var muted = true
    private val uiHandler = Handler(Looper.getMainLooper())

    init {
        surfaceTextureListener = this
        isOpaque = false
    }

    override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
        startPlayer(st)
    }

    override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {}

    override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
        release()
        return true
    }

    override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}

    private fun startPlayer(st: SurfaceTexture) {
        val u = uri ?: return
        release()
        try {
            val s = Surface(st)
            surface = s
            val p = MediaPlayer()
            player = p
            p.setDataSource(context, u)
            p.setSurface(s)
            p.isLooping = loop
            val vol = if (muted) 0f else 1f
            p.setVolume(vol, vol)
            p.setOnPreparedListener { mp ->
                prepared = true
                ended = false
                mp.start()
                if (!playing) {
                    // Показываем первый кадр и ставим на паузу.
                    uiHandler.postDelayed({
                        try {
                            if (!playing && prepared) mp.pause()
                        } catch (e: Exception) {
                        }
                    }, 150)
                }
            }
            p.setOnCompletionListener { ended = true }
            p.setOnErrorListener { _, _, _ -> true }
            p.prepareAsync()
        } catch (e: Exception) {
            // Файл недоступен — просто пустой кадр.
        }
    }

    fun applyState(newPlaying: Boolean, newLoop: Boolean, newMuted: Boolean) {
        val wasPlaying = playing
        playing = newPlaying
        loop = newLoop
        muted = newMuted
        val p = player ?: return
        try {
            p.isLooping = loop
            val vol = if (muted) 0f else 1f
            p.setVolume(vol, vol)
            if (prepared) {
                if (!wasPlaying && playing && ended) {
                    replay()
                } else if (playing && !p.isPlaying && !ended) {
                    p.start()
                } else if (!playing && p.isPlaying) {
                    p.pause()
                }
            }
        } catch (e: Exception) {
        }
    }

    fun replay() {
        val p = player ?: return
        if (!prepared) return
        try {
            p.seekTo(0)
            p.start()
            playing = true
            ended = false
        } catch (e: Exception) {
        }
    }

    fun release() {
        prepared = false
        uiHandler.removeCallbacksAndMessages(null)
        try {
            player?.release()
        } catch (e: Exception) {
        }
        player = null
        try {
            surface?.release()
        } catch (e: Exception) {
        }
        surface = null
    }
}
