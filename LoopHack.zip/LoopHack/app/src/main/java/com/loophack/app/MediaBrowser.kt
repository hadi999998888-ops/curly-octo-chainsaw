package com.loophack.app

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MediaEntry(val uri: Uri, val title: String, val sub: String)

/** Доступ к фото, видео и музыке устройства через MediaStore. */
object MediaAccess {
    const val AUDIO = "audio"

    fun permissions(): Array<String> =
        if (Build.VERSION.SDK_INT >= 33) {
            arrayOf(
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_AUDIO
            )
        } else {
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }

    fun has(ctx: Context, kind: String): Boolean {
        val p = if (Build.VERSION.SDK_INT >= 33) {
            when (kind) {
                Type.VIDEO -> Manifest.permission.READ_MEDIA_VIDEO
                AUDIO -> Manifest.permission.READ_MEDIA_AUDIO
                else -> Manifest.permission.READ_MEDIA_IMAGES
            }
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
        return ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    }

    fun query(ctx: Context, kind: String, limit: Int): List<MediaEntry> {
        val coll: Uri
        val proj: Array<String>
        var sel: String? = null
        when (kind) {
            Type.VIDEO -> {
                coll = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                proj = arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME)
            }
            AUDIO -> {
                coll = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                proj = arrayOf(
                    MediaStore.MediaColumns._ID,
                    MediaStore.Audio.Media.TITLE,
                    MediaStore.Audio.Media.ARTIST
                )
                sel = MediaStore.Audio.Media.IS_MUSIC + " != 0"
            }
            else -> {
                coll = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                proj = arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME)
            }
        }
        val out = ArrayList<MediaEntry>()

        fun run(selection: String?) {
            try {
                ctx.contentResolver.query(
                    coll, proj, selection, null, MediaStore.MediaColumns.DATE_ADDED + " DESC"
                )?.use { c ->
                    val idI = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                    val nameI = c.getColumnIndexOrThrow(
                        if (kind == AUDIO) MediaStore.Audio.Media.TITLE else MediaStore.MediaColumns.DISPLAY_NAME
                    )
                    val artI = if (kind == AUDIO) c.getColumnIndex(MediaStore.Audio.Media.ARTIST) else -1
                    while (c.moveToNext() && out.size < limit) {
                        var sub = if (artI >= 0) (c.getString(artI) ?: "") else ""
                        if (sub == "<unknown>") sub = ""
                        out.add(
                            MediaEntry(
                                ContentUris.withAppendedId(coll, c.getLong(idI)),
                                c.getString(nameI) ?: "",
                                sub
                            )
                        )
                    }
                }
            } catch (e: Exception) {
            }
        }
        run(sel)
        if (out.isEmpty() && sel != null) run(null)
        return out
    }
}

/** Превью в фоне: список не подвисает, повторные показы берутся из кэша. */
object Thumbs {
    private val cache = LruCache<String, Bitmap>(90)
    private val pool: ExecutorService = Executors.newFixedThreadPool(3)
    private val main = Handler(Looper.getMainLooper())

    fun load(ctx: Context, uri: Uri, size: Int, into: ImageView) {
        val key = uri.toString()
        into.tag = key
        val hit = cache.get(key)
        if (hit != null) {
            into.setImageBitmap(hit)
            return
        }
        into.setImageDrawable(null)
        val app = ctx.applicationContext
        pool.execute {
            val bmp = decode(app, uri, size)
            if (bmp != null) {
                cache.put(key, bmp)
                main.post {
                    if (into.tag == key) into.setImageBitmap(bmp)
                }
            }
        }
    }

    private fun decode(ctx: Context, uri: Uri, size: Int): Bitmap? {
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                ctx.contentResolver.loadThumbnail(uri, Size(size, size), null)
            } else {
                legacy(ctx, uri, size)
            }
        } catch (e: Throwable) {
            null
        }
    }

    private fun legacy(ctx: Context, uri: Uri, size: Int): Bitmap? {
        val type = ctx.contentResolver.getType(uri) ?: ""
        if (type.startsWith("video")) {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(ctx, uri)
                return r.getFrameAtTime(0)
            } finally {
                r.release()
            }
        }
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / sample > size * 2 || bounds.outHeight / sample > size * 2) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        return ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
    }
}

/** Готовые виды для встроенной галереи и списка музыки. */
object MediaViews {

    /** Сетка превью по три в ряд. kind: Type.IMAGE или Type.VIDEO. */
    fun grid(ctx: Context, kind: String, cell: Int, onPick: (MediaEntry) -> Unit): View {
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        val entries = MediaAccess.query(ctx, kind, 90)
        if (entries.isEmpty()) {
            col.addView(Ui.text(ctx, "Здесь пока ничего нет.", 13f, Ui.GRAY))
            return col
        }
        val gap = Ui.dp(ctx, 3)
        var row: LinearLayout? = null
        entries.forEachIndexed { i, e ->
            if (i % 3 == 0) {
                row = LinearLayout(ctx)
                row?.orientation = LinearLayout.HORIZONTAL
                col.addView(row, Ui.lin(Ui.WRAP, Ui.WRAP))
            }
            val box = FrameLayout(ctx)
            box.background = Ui.rounded(Ui.PANEL2, Ui.dp(ctx, 10).toFloat())
            val iv = ImageView(ctx)
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            box.addView(iv, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
            if (kind == Type.VIDEO) {
                val tag = Ui.text(ctx, "▶", 12f, Ui.WHITE, true)
                tag.setShadowLayer(4f, 0f, 0f, Ui.BLACK)
                box.addView(
                    tag,
                    FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.BOTTOM or Gravity.START).apply {
                        setMargins(Ui.dp(ctx, 6), 0, 0, Ui.dp(ctx, 4))
                    }
                )
            }
            box.isClickable = true
            box.setOnClickListener {
                box.animate().scaleX(0.92f).scaleY(0.92f).setDuration(80).withEndAction {
                    box.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                }.start()
                onPick(e)
            }
            Thumbs.load(ctx, e.uri, cell, iv)
            row?.addView(box, Ui.lin(cell, cell, 0f, gap, gap, gap, gap))
        }
        return col
    }

    /** Список треков. */
    fun audioList(ctx: Context, onPick: (MediaEntry) -> Unit): View {
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        val entries = MediaAccess.query(ctx, MediaAccess.AUDIO, 200)
        if (entries.isEmpty()) {
            col.addView(Ui.text(ctx, "Музыка на устройстве не найдена.", 13f, Ui.GRAY))
            return col
        }
        for (e in entries) {
            val row = LinearLayout(ctx)
            row.orientation = LinearLayout.VERTICAL
            row.background = Ui.rounded(Ui.PANEL, Ui.dp(ctx, 12).toFloat(), 0x22FFFFFF, Ui.dp(ctx, 1))
            row.setPadding(Ui.dp(ctx, 12), Ui.dp(ctx, 9), Ui.dp(ctx, 12), Ui.dp(ctx, 9))
            val t = Ui.text(ctx, e.title, 14f, Ui.WHITE, true)
            t.maxLines = 1
            t.ellipsize = android.text.TextUtils.TruncateAt.END
            row.addView(t)
            if (e.sub.isNotEmpty()) row.addView(Ui.text(ctx, e.sub, 12f, Ui.GRAY))
            row.isClickable = true
            row.setOnClickListener { onPick(e) }
            col.addView(row, Ui.lin(Ui.MATCH, Ui.WRAP, 0f, 0, 0, 0, Ui.dp(ctx, 6)))
        }
        return col
    }

    /** Показывается, пока нет доступа к фото, видео или музыке. */
    fun needPermission(ctx: Context, onRequest: () -> Unit): View {
        val card = Ui.card(ctx)
        card.addView(Ui.text(ctx, "Нужен доступ к медиафайлам", 15f, Ui.WHITE, true))
        card.addView(
            Ui.text(
                ctx,
                "Разрешите доступ один раз, и фото, видео и музыку можно будет выбирать прямо здесь, " +
                        "не выходя из игры.",
                13f, Ui.GRAY
            ),
            Ui.lin(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 6), 0, Ui.dp(ctx, 10))
        )
        card.addView(Ui.button(ctx, "Разрешить доступ", 0) { onRequest() })
        return card
    }
}
