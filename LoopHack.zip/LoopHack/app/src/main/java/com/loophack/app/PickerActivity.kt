package com.loophack.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns

/**
 * Прозрачный экран-посредник. Типы:
 *  image / video — открывает системную галерею и добавляет выбранное;
 *  perm — один раз запрашивает доступ к фото, видео и музыке (для встроенной галереи оверлея).
 */
class PickerActivity : Activity() {

    private var type = Type.IMAGE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        type = intent.getStringExtra("type") ?: Type.IMAGE
        if (savedInstanceState != null) return

        if (type == "perm") {
            requestPermissions(MediaAccess.permissions(), 7)
            return
        }
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = if (type == Type.VIDEO) "video/*" else "image/*"
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        try {
            startActivityForResult(i, 1)
        } catch (e: Exception) {
            Ui.toast(this, "Не удалось открыть галерею")
            finish()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        OverlayService.refresh()
        finish()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK && data != null) {
            val uris = mutableListOf<Uri>()
            data.data?.let { uris.add(it) }
            val cd = data.clipData
            if (cd != null) {
                for (i in 0 until cd.itemCount) uris.add(cd.getItemAt(i).uri)
            }
            val all = uris.distinct()
            for (u in all) {
                try {
                    contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (e: Exception) {
                    // Не все провайдеры поддерживают постоянный доступ.
                }
                val item = Item(
                    id = Repo.newId(),
                    type = type,
                    uri = u.toString(),
                    name = displayName(u),
                    baseWidth = Repo.mediaWidth(this).toFloat()
                )
                Repo.place(this, item)
                Repo.add(this, item)
            }
            if (all.isNotEmpty()) {
                OverlayService.refresh()
                Ui.toast(this, "Добавлено: ${all.size}")
            }
        }
        finish()
    }

    private fun displayName(u: Uri): String {
        return try {
            contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) ?: "" else ""
            } ?: ""
        } catch (e: Exception) {
            ""
        }
    }
}
