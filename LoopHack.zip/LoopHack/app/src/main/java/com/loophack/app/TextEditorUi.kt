package com.loophack.app

import android.content.Context
import android.view.Gravity
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout

/** Все элементы настройки текста: используются и в приложении, и в оверлей-меню. */
object TextEditorUi {

    /** Рисует предпросмотр текста в рамке. */
    fun renderPreview(ctx: Context, box: FrameLayout, item: Item) {
        box.removeAllViews()
        val tmp = item.copy(text = item.text.ifEmpty { "Ваш текст" })
        val v = ItemViews.makeText(ctx, tmp, 1f)
        v.alpha = item.alpha.coerceIn(0.05f, 1f)
        box.addView(v, FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.CENTER))
    }

    /**
     * Строит панель настроек и меняет item по ходу. onChange вызывается после каждого изменения.
     * attachInput подключает клавиатуру, когда поле находится в оверлее.
     */
    fun build(
        ctx: Context,
        item: Item,
        attachInput: (EditText) -> Unit,
        onChange: () -> Unit
    ): LinearLayout {
        fun dp(v: Int) = Ui.dp(ctx, v)

        val body = LinearLayout(ctx)
        body.orientation = LinearLayout.VERTICAL

        fun heading(s: String) {
            body.addView(Ui.sectionTitle(ctx, s), Ui.lin(Ui.WRAP, Ui.WRAP, 0f, 0, dp(14), 0, dp(2)))
        }

        // Текст
        heading("ТЕКСТ")
        val edit = Ui.field(ctx, "Введите текст", item.text, true)
        attachInput(edit)
        Ui.watch(edit) { s ->
            item.text = s
            onChange()
        }
        body.addView(edit, Ui.lin(Ui.MATCH, Ui.WRAP))

        body.addView(
            Ui.seek(ctx, "Размер текста", 8, 120, item.textSize.toInt(), { "$it" }) {
                item.textSize = it.toFloat()
                onChange()
            }
        )
        body.addView(Ui.colorRow(ctx, "Цвет текста", item.textColor, attachInput) {
            item.textColor = it
            onChange()
        })
        body.addView(Ui.toggle(ctx, "Жирный текст", item.bold) {
            item.bold = it
            onChange()
        })
        body.addView(
            Ui.seek(ctx, "Прозрачность", 5, 100, (item.alpha * 100).toInt(), { "$it%" }) {
                item.alpha = it / 100f
                onChange()
            }
        )

        // Шрифт
        heading("ШРИФТ")
        val fs = HorizontalScrollView(ctx)
        fs.isHorizontalScrollBarEnabled = false
        val fontRow = LinearLayout(ctx)
        fontRow.orientation = LinearLayout.HORIZONTAL
        fs.addView(fontRow)
        body.addView(fs, Ui.lin(Ui.MATCH, Ui.WRAP, 0f, 0, dp(4), 0, 0))

        fun refreshFonts() {
            fontRow.removeAllViews()
            ItemViews.fontNames.forEachIndexed { i, name ->
                fontRow.addView(
                    Ui.chip(ctx, name, item.font == i) {
                        item.font = i
                        refreshFonts()
                        onChange()
                    },
                    Ui.lin(Ui.WRAP, Ui.WRAP, 0f, 0, 0, dp(8), 0)
                )
            }
        }
        refreshFonts()

        // Фон
        heading("ФОН ТЕКСТА")
        body.addView(Ui.toggle(ctx, "Цветной фон", item.bgEnabled) {
            item.bgEnabled = it
            onChange()
        })
        body.addView(Ui.colorRow(ctx, "Цвет фона", item.bgColor, attachInput) {
            item.bgColor = it
            onChange()
        })
        body.addView(
            Ui.seek(ctx, "Ширина фона (отступ по бокам)", 0, 80, item.padH.toInt(), { "$it" }) {
                item.padH = it.toFloat()
                onChange()
            }
        )
        body.addView(
            Ui.seek(ctx, "Высота фона (отступ сверху/снизу)", 0, 60, item.padV.toInt(), { "$it" }) {
                item.padV = it.toFloat()
                onChange()
            }
        )

        // Обводка
        heading("ОБВОДКА")
        body.addView(
            Ui.seek(ctx, "Толщина обводки", 0, 12, item.strokeWidth.toInt(), { "$it" }) {
                item.strokeWidth = it.toFloat()
                onChange()
            }
        )
        body.addView(Ui.colorRow(ctx, "Цвет обводки", item.strokeColor, attachInput) {
            item.strokeColor = it
            onChange()
        })

        // Свечение
        heading("СВЕЧЕНИЕ")
        body.addView(
            Ui.seek(ctx, "Сила свечения", 0, 40, item.glow.toInt(), { "$it" }) {
                item.glow = it.toFloat()
                onChange()
            }
        )
        body.addView(Ui.colorRow(ctx, "Цвет свечения", item.glowColor, attachInput) {
            item.glowColor = it
            onChange()
        })
        return body
    }
}
