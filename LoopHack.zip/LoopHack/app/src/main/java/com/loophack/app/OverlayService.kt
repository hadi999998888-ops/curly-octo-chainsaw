package com.loophack.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.drawable.Icon
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.WindowManager
import androidx.core.content.ContextCompat

/** Foreground-сервис: держит окна элементов, стрелку-ручку, меню и уведомление для стримов. */
class OverlayService : Service() {

    companion object {
        const val ACTION_STOP = "com.loophack.app.action.STOP"
        private const val CHANNEL = "loophack_overlay"
        private const val NOTIF_ID = 1001

        @Volatile
        var instance: OverlayService? = null

        val running: Boolean get() = instance != null

        fun start(c: Context) {
            ContextCompat.startForegroundService(c, Intent(c, OverlayService::class.java))
        }

        fun stop(c: Context) {
            c.stopService(Intent(c, OverlayService::class.java))
        }

        /** Перечитать элементы из хранилища и обновить окна. menu=false — не перестраивать меню (во время ползунков). */
        fun refresh(menu: Boolean = true) {
            instance?.sync(menu)
        }

        fun refreshNotifier() {
            instance?.notifier?.apply()
        }

        fun previewNotify() {
            instance?.notifier?.preview()
        }

        /** Применить настройки музыки (трек, пауза/игра, громкость, повтор). */
        fun musicSync() {
            instance?.music?.sync()
        }

        fun relayoutMenu() {
            instance?.menu?.relayout()
        }

        fun replay(id: String) {
            instance?.windows?.get(id)?.replay()
        }
    }

    private val windows = LinkedHashMap<String, OverlayWindow>()
    private val attachedOrder = ArrayList<String>()
    private var menu: OverlayMenu? = null
    private var notifier: StreamNotifier? = null
    private var music: MusicPlayer? = null
    private var lastW = 0
    private var lastH = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        lastW = Screen.w(this)
        lastH = Screen.h(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            startAsForeground()
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!Settings.canDrawOverlays(this) || !Repo.gateOpen(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (menu == null) {
            menu = OverlayMenu(this, wm) { stopSelf() }
        }
        if (notifier == null) {
            notifier = StreamNotifier(this, wm)
        }
        if (music == null) {
            music = MusicPlayer(this)
        }
        sync(true)
        menu?.start()
        notifier?.apply()
        music?.sync()
        return START_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "LOOP HACK — оверлеи", NotificationManager.IMPORTANCE_LOW)
        )
        val pf = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), pf)
        val stopIntent = Intent(this, OverlayService::class.java).setAction(ACTION_STOP)
        val stop = PendingIntent.getService(this, 1, stopIntent, pf)
        val action = Notification.Action.Builder(
            Icon.createWithResource(this, R.drawable.ic_stat), "Остановить", stop
        ).build()
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("LOOP HACK")
            .setContentText("Оверлеи активны. Зажмите стрелку внизу экрана и проведите вверх")
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(action)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun persist(item: Item) {
        Repo.mutate(this, item.id) {
            it.cx = item.cx
            it.cy = item.cy
            it.scale = item.scale
            it.rotation = item.rotation
        }
        menu?.refreshItems()
    }

    fun sync(refreshMenu: Boolean = true) {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val items = Repo.load(this)
        val ids = items.map { it.id }.toSet()

        for (id in windows.keys.filter { it !in ids }) {
            windows.remove(id)?.destroy()
            attachedOrder.remove(id)
        }
        for (item in items) {
            val w = windows[item.id]
            if (w == null) {
                windows[item.id] = OverlayWindow(this, wm, item) { persist(it) }
            } else {
                w.update(item)
            }
        }

        // Порядок слоёв = порядок в списке (последний — самый верхний).
        val desired = items.filter { it.visible }.map { it.id }
        val needReorder = desired != attachedOrder || desired.any { windows[it]?.attached != true }
        if (needReorder) {
            for (id in attachedOrder.toList()) windows[id]?.detach()
            attachedOrder.clear()
            for (id in desired) windows[id]?.attach()
            attachedOrder.addAll(desired)
            // Стрелка и меню всегда выше элементов.
            menu?.raise()
        }
        if (refreshMenu) menu?.refreshIfOpen()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val nw = Screen.w(this)
        val nh = Screen.h(this)
        if (lastW > 0 && lastH > 0 && (nw != lastW || nh != lastH)) {
            val kx = nw.toFloat() / lastW
            val ky = nh.toFloat() / lastH
            Repo.mutateAll(this) {
                it.cx = (it.cx * kx).coerceIn(0f, nw.toFloat())
                it.cy = (it.cy * ky).coerceIn(0f, nh.toFloat())
            }
        }
        lastW = nw
        lastH = nh
        sync(false)
        menu?.relayout()
    }

    override fun onDestroy() {
        music?.destroy()
        music = null
        notifier?.destroy()
        notifier = null
        menu?.destroy()
        menu = null
        for (w in windows.values) w.destroy()
        windows.clear()
        attachedOrder.clear()
        instance = null
        Repo.flush()
        super.onDestroy()
    }
}
