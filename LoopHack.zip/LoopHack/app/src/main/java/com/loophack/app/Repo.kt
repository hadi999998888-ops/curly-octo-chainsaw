package com.loophack.app

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import java.util.UUID

/**
 * Хранилище элементов и настроек. Элементы живут в памяти (быстро, без разбора JSON на каждый
 * сдвиг ползунка), на диск записываются с задержкой. Вызывать только из главного потока.
 */
object Repo {
    private const val PREFS = "loophack"
    private const val KEY_ITEMS = "items"
    private const val KEY_SEEDED = "seeded"
    private const val KEY_MEDIA_W = "mediaWidth"

    private var cache: MutableList<Item>? = null
    private var appCtx: Context? = null
    private var flushPending = false
    private val main = Handler(Looper.getMainLooper())

    private fun sp(c: Context) =
        c.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun newId(): String = UUID.randomUUID().toString()

    private fun readDisk(c: Context): MutableList<Item> {
        val s = sp(c).getString(KEY_ITEMS, null) ?: return mutableListOf()
        return try {
            val a = JSONArray(s)
            // Рекламного щита больше нет: старые логотипы отбрасываем.
            MutableList(a.length()) { Item.fromJson(a.getJSONObject(it)) }.filter { it.type != Type.LOGO }.toMutableList()
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    /** Возвращает копии элементов: их можно менять и передавать в save(). */
    fun load(c: Context): MutableList<Item> {
        var l = cache
        if (l == null) {
            l = readDisk(c)
            cache = l
        }
        appCtx = c.applicationContext
        return l.mapTo(ArrayList(l.size)) { it.copy() }
    }

    fun save(c: Context, list: List<Item>) {
        cache = list.mapTo(ArrayList(list.size)) { it.copy() }
        appCtx = c.applicationContext
        if (!flushPending) {
            flushPending = true
            main.postDelayed({ flush() }, 300)
        }
    }

    /** Немедленно записывает элементы на диск. */
    fun flush() {
        flushPending = false
        val c = appCtx ?: return
        val l = cache ?: return
        val a = JSONArray()
        l.forEach { a.put(it.toJson()) }
        sp(c).edit().putString(KEY_ITEMS, a.toString()).apply()
    }

    fun add(c: Context, item: Item) {
        val l = load(c)
        l.add(item)
        save(c, l)
    }

    fun remove(c: Context, id: String) {
        val l = load(c)
        l.removeAll { it.id == id }
        save(c, l)
    }

    fun clear(c: Context) = save(c, emptyList())

    fun mutate(c: Context, id: String, block: (Item) -> Unit) {
        val l = load(c)
        val item = l.find { it.id == id } ?: return
        block(item)
        save(c, l)
    }

    fun mutateAll(c: Context, block: (Item) -> Unit) {
        val l = load(c)
        l.forEach(block)
        save(c, l)
    }

    fun find(c: Context, id: String): Item? = load(c).find { it.id == id }

    /** delta = +1 — выше слоем (ближе к зрителю), -1 — ниже. */
    fun move(c: Context, id: String, delta: Int) {
        val l = load(c)
        val i = l.indexOfFirst { it.id == id }
        val j = i + delta
        if (i < 0 || j < 0 || j >= l.size) return
        val t = l[i]
        l[i] = l[j]
        l[j] = t
        save(c, l)
    }

    /** Ставит новый элемент в видимую область со смещением, чтобы элементы не слипались. */
    fun place(c: Context, item: Item) {
        val d = c.resources.displayMetrics.density
        val n = load(c).size % 6
        item.cx = Screen.w(c) / 2f + (n - 3) * 24f * d
        item.cy = Screen.h(c) / 3f + n * 28f * d
    }

    fun mediaWidth(c: Context): Int = sp(c).getInt(KEY_MEDIA_W, 200)

    fun setMediaWidth(c: Context, v: Int) {
        sp(c).edit().putInt(KEY_MEDIA_W, v).apply()
    }

    /** Экран-замок: открывается после перехода по ссылке на Telegram-канал. */
    fun gateOpen(c: Context): Boolean = sp(c).getBoolean("gateOpen", false)

    fun openGate(c: Context) {
        sp(c).edit().putBoolean("gateOpen", true).apply()
    }

    // --- Стрелка-ручка ---
    /** Положение стрелки по горизонтали: 0..1 от доступной ширины. */
    fun handleX(c: Context): Float = sp(c).getFloat("handleX", 0.5f)

    fun setHandleX(c: Context, v: Float) {
        sp(c).edit().putFloat("handleX", v).apply()
    }

    /** Высота стрелки над нижним краем, dp. */
    fun handleY(c: Context): Int = sp(c).getInt("handleY", 2)

    fun setHandleY(c: Context, v: Int) {
        sp(c).edit().putInt("handleY", v).apply()
    }

    /** Прозрачность стрелки в покое, %. */
    fun handleAlpha(c: Context): Int = sp(c).getInt("handleAlpha", 55)

    fun setHandleAlpha(c: Context, v: Int) {
        sp(c).edit().putInt("handleAlpha", v).apply()
    }

    // --- Уведомление для стримов ---
    fun notifyEnabled(c: Context): Boolean = sp(c).getBoolean("nEnabled", false)

    fun setNotifyEnabled(c: Context, v: Boolean) {
        sp(c).edit().putBoolean("nEnabled", v).apply()
    }

    fun notifyInterval(c: Context): Int = sp(c).getInt("nInterval", 20)

    fun setNotifyInterval(c: Context, v: Int) {
        sp(c).edit().putInt("nInterval", v).apply()
    }

    fun notifyName(c: Context): String = sp(c).getString("nName", null) ?: "Loop Hack"

    fun setNotifyName(c: Context, v: String) {
        sp(c).edit().putString("nName", v).apply()
    }

    fun notifyText(c: Context): String = sp(c).getString("nText", null) ?: "Подпишись на канал!"

    fun setNotifyText(c: Context, v: String) {
        sp(c).edit().putString("nText", v).apply()
    }

    /** URI аватарки отправителя; пустая строка — логотип LOOP HACK. */
    fun notifyAvatar(c: Context): String = sp(c).getString("nAvatar", null) ?: ""

    fun setNotifyAvatar(c: Context, v: String) {
        sp(c).edit().putString("nAvatar", v).apply()
    }

    // --- Фоновая музыка ---
    fun musicUri(c: Context): String = sp(c).getString("mUri", null) ?: ""

    fun musicName(c: Context): String = sp(c).getString("mName", null) ?: ""

    fun setMusicTrack(c: Context, uri: String, name: String) {
        sp(c).edit().putString("mUri", uri).putString("mName", name).apply()
    }

    fun musicVol(c: Context): Int = sp(c).getInt("mVol", 60)

    fun setMusicVol(c: Context, v: Int) {
        sp(c).edit().putInt("mVol", v).apply()
    }

    fun musicLoop(c: Context): Boolean = sp(c).getBoolean("mLoop", true)

    fun setMusicLoop(c: Context, v: Boolean) {
        sp(c).edit().putBoolean("mLoop", v).apply()
    }

    fun musicPlay(c: Context): Boolean = sp(c).getBoolean("mPlay", false)

    fun setMusicPlay(c: Context, v: Boolean) {
        sp(c).edit().putBoolean("mPlay", v).apply()
    }
}
