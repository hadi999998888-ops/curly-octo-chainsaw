package com.loophack.app

import android.content.Context
import android.graphics.PixelFormat
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin

/**
 * Один элемент = одно отдельное окно поверх экрана. Поэтому каждый элемент
 * двигается, масштабируется, вращается, закрепляется и скрывается независимо.
 */
class OverlayWindow(
    private val ctx: Context,
    private val wm: WindowManager,
    initial: Item,
    private val onChanged: (Item) -> Unit
) {
    companion object {
        private const val BASE_FLAGS = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
    }

    var item: Item = initial
        private set
    var attached = false
        private set

    private val dm = ctx.resources.displayMetrics
    private val root = FrameLayout(ctx).apply {
        clipChildren = false
        clipToPadding = false
    }
    private var content: View? = null
    private var video: VideoLayer? = null
    private var key = ""
    private var lastSig = ""
    private var cw = 1
    private var ch = 1

    private val lp = WindowManager.LayoutParams(
        1, 1,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        BASE_FLAGS,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 30) {
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        } else if (Build.VERSION.SDK_INT >= 28) {
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }

    // --- состояние жеста ---
    private var lastX = 0f
    private var lastY = 0f
    private var lastDist = 0f
    private var lastAng = 0f
    private var gesture = false

    init {
        var placed = false
        if (item.cx < 0f || item.cy < 0f) {
            item.cx = Screen.w(ctx) / 2f
            item.cy = Screen.h(ctx) / 3f
            placed = true
        }
        root.setOnTouchListener { _, e -> onTouch(e) }
        key = keyOf(item)
        build()
        if (placed) onChanged(item)
    }

    private fun keyOf(n: Item): String = n.copy(
        cx = 0f, cy = 0f, scale = 1f, rotation = 0f, locked = false, visible = true,
        alpha = 1f, playing = true, loop = true, muted = true
    ).toString()

    fun update(n: Item) {
        item = n
        val k = keyOf(n)
        if (k != key || content == null) {
            key = k
            build()
        } else if (sigOf(n) != lastSig) {
            relayout()
        }
        video?.applyState(item.playing, item.loop, item.muted)
    }

    private fun sigOf(n: Item): String =
        "${n.cx}|${n.cy}|${n.scale}|${n.rotation}|${n.alpha}|${n.locked}"

    fun replay() {
        video?.replay()
    }

    fun attach() {
        if (attached) return
        try {
            wm.addView(root, lp)
            attached = true
        } catch (e: Exception) {
            attached = false
        }
    }

    fun detach() {
        if (!attached) return
        try {
            wm.removeView(root)
        } catch (e: Exception) {
        }
        attached = false
    }

    fun destroy() {
        detach()
        video?.release()
        video = null
    }

    // ------------------------------------------------------------------ сборка содержимого

    private fun build() {
        root.removeAllViews()
        video?.release()
        video = null
        val d = dm.density
        val v: View
        when (item.type) {
            Type.TEXT -> {
                val t = ItemViews.makeText(ctx, item, 1f)
                t.measure(
                    View.MeasureSpec.makeMeasureSpec(Screen.w(ctx), View.MeasureSpec.AT_MOST),
                    View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
                )
                cw = max(1, t.measuredWidth)
                ch = max(1, t.measuredHeight)
                v = t
            }
            Type.LOGO -> {
                cw = max(1, (item.baseWidth * d).toInt())
                ch = cw
                v = ImageView(ctx).apply {
                    setImageResource(R.drawable.logo)
                    scaleType = ImageView.ScaleType.FIT_XY
                }
            }
            Type.IMAGE -> {
                cw = max(1, (item.baseWidth * d).toInt())
                val bmp = ItemViews.decodeBitmap(ctx, Uri.parse(item.uri))
                if (bmp != null) {
                    ch = max(1, (cw * bmp.height.toFloat() / bmp.width).toInt())
                    v = ImageView(ctx).apply {
                        setImageBitmap(bmp)
                        scaleType = ImageView.ScaleType.FIT_XY
                    }
                } else {
                    ch = cw
                    v = placeholder("Фото недоступно")
                }
            }
            else -> {
                cw = max(1, (item.baseWidth * d).toInt())
                val sz = videoSize(Uri.parse(item.uri))
                ch = max(1, (cw * sz.second.toFloat() / sz.first).toInt())
                val vl = VideoLayer(ctx)
                vl.uri = Uri.parse(item.uri)
                vl.applyState(item.playing, item.loop, item.muted)
                video = vl
                v = vl
            }
        }
        root.addView(v, FrameLayout.LayoutParams(cw, ch, Gravity.CENTER))
        content = v
        relayout()
    }

    private fun placeholder(msg: String): View = TextView(ctx).apply {
        text = msg
        setTextColor(0xFFFFFFFF.toInt())
        gravity = Gravity.CENTER
        setBackgroundColor(0xAA000000.toInt())
    }

    private fun videoSize(uri: Uri): Pair<Int, Int> {
        var w = 16
        var h = 9
        try {
            val r = MediaMetadataRetriever()
            r.setDataSource(ctx, uri)
            val vw = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull()
            val vh = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull()
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            r.release()
            if (vw != null && vh != null && vw > 0 && vh > 0) {
                if (rot == 90 || rot == 270) {
                    w = vh
                    h = vw
                } else {
                    w = vw
                    h = vh
                }
            }
        } catch (e: Exception) {
        }
        return Pair(w, h)
    }

    // ------------------------------------------------------------------ геометрия

    private fun maxScale(): Float = max(0.2f, 4000f / (cw + ch))

    private fun relayout() {
        val c = content ?: return
        item.scale = item.scale.coerceIn(0.1f, maxScale())
        val s = item.scale
        val r = Math.toRadians(item.rotation.toDouble())
        val w = cw * s
        val h = ch * s
        val bw = abs(w * cos(r)) + abs(h * sin(r))
        val bh = abs(w * sin(r)) + abs(h * cos(r))
        lp.width = ceil(bw).toInt() + 2
        lp.height = ceil(bh).toInt() + 2
        lp.x = (item.cx - lp.width / 2f).toInt()
        lp.y = (item.cy - lp.height / 2f).toInt()
        c.scaleX = s
        c.scaleY = s
        c.rotation = item.rotation

        // Закреплённый элемент не реагирует на касания (на Android до 12 касания уходят в приложение под ним).
        // Прозрачность всегда ровно та, что задал пользователь: окно рисуется с alpha = 1.
        lp.flags = if (item.locked) BASE_FLAGS or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE else BASE_FLAGS
        lp.alpha = 1f
        c.alpha = item.alpha.coerceIn(0.05f, 1f)
        lastSig = sigOf(item)
        if (attached) {
            try {
                wm.updateViewLayout(root, lp)
            } catch (e: Exception) {
            }
        }
    }

    // ------------------------------------------------------------------ жесты

    private fun points(e: MotionEvent, skip: Int): List<FloatArray> {
        val ox = e.rawX - e.getX(0)
        val oy = e.rawY - e.getY(0)
        val l = ArrayList<FloatArray>(2)
        for (i in 0 until e.pointerCount) {
            if (i == skip) continue
            l.add(floatArrayOf(e.getX(i) + ox, e.getY(i) + oy))
        }
        return l
    }

    private fun baseline(e: MotionEvent, skip: Int) {
        val p = points(e, skip)
        if (p.isEmpty()) return
        lastX = p.map { it[0] }.average().toFloat()
        lastY = p.map { it[1] }.average().toFloat()
        if (p.size >= 2) {
            lastDist = hypot(p[1][0] - p[0][0], p[1][1] - p[0][1])
            lastAng = Math.toDegrees(atan2((p[1][1] - p[0][1]).toDouble(), (p[1][0] - p[0][0]).toDouble())).toFloat()
        } else {
            lastDist = 0f
        }
    }

    private fun onTouch(e: MotionEvent): Boolean {
        if (item.locked) return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                baseline(e, -1)
                gesture = true
            }
            MotionEvent.ACTION_POINTER_UP -> {
                baseline(e, e.actionIndex)
                gesture = true
            }
            MotionEvent.ACTION_MOVE -> if (gesture) move(e)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (gesture) {
                    gesture = false
                    onChanged(item)
                }
            }
        }
        return true
    }

    private fun move(e: MotionEvent) {
        val p = points(e, -1)
        if (p.isEmpty()) return
        val x = p.map { it[0] }.average().toFloat()
        val y = p.map { it[1] }.average().toFloat()
        item.cx += x - lastX
        item.cy += y - lastY
        lastX = x
        lastY = y
        if (p.size >= 2) {
            val dx = p[1][0] - p[0][0]
            val dy = p[1][1] - p[0][1]
            val dist = hypot(dx, dy)
            val ang = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()
            if (lastDist > 0f && dist > 0f) {
                item.scale = (item.scale * dist / lastDist).coerceIn(0.1f, maxScale())
                var da = ang - lastAng
                while (da > 180f) da -= 360f
                while (da < -180f) da += 360f
                item.rotation += da
                if (item.rotation > 180f) item.rotation -= 360f
                if (item.rotation < -180f) item.rotation += 360f
            }
            lastDist = dist
            lastAng = ang
        } else {
            lastDist = 0f
        }
        relayout()
    }
}
