package com.loophack.app

import android.content.Context
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout

/**
 * Карточка одного элемента с ползунками и кнопками.
 * Используется и в приложении, и в оверлей-меню.
 * onChange вызывается после действий, меняющих список (скрыть, закрепить, порядок, удаление, видео).
 */
object ItemPanel {

    fun card(ctx: Context, item: Item, onEdit: (String) -> Unit, onChange: () -> Unit): View {
        val id = item.id

        fun dp(v: Int) = Ui.dp(ctx, v)

        fun act(block: (Item) -> Unit) {
            Repo.mutate(ctx, id, block)
            OverlayService.refresh(false)
            onChange()
        }

        val card = Ui.card(ctx)
        card.setPadding(dp(12), dp(10), dp(12), dp(12))

        // Заголовок
        val head = LinearLayout(ctx)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val icon = when (item.type) {
            Type.TEXT -> "Aa"
            Type.IMAGE -> "🖼"
            Type.VIDEO -> "🎬"
            else -> "◆"
        }
        head.addView(Ui.text(ctx, icon, 17f, Ui.WHITE, true), Ui.lin(Ui.WRAP, Ui.WRAP, 0f, 0, 0, dp(10), 0))
        val title = Ui.text(ctx, item.title(), 14f, Ui.WHITE, true)
        title.maxLines = 1
        title.ellipsize = TextUtils.TruncateAt.END
        head.addView(title, Ui.lin(0, Ui.WRAP, 1f))
        val state = when {
            !item.visible -> "скрыт"
            item.locked -> "закреплён"
            else -> "активен"
        }
        head.addView(Ui.text(ctx, state, 11f, if (item.visible) Ui.PINK else Ui.GRAY, true))
        card.addView(head)

        // Ползунки рядом
        val sliders = LinearLayout(ctx)
        sliders.orientation = LinearLayout.HORIZONTAL
        sliders.addView(
            Ui.seek(ctx, "Прозрачность", 5, 100, (item.alpha * 100).toInt(), { "$it%" }) { v ->
                Repo.mutate(ctx, id) { x -> x.alpha = v / 100f }
                OverlayService.refresh(false)
            },
            Ui.lin(0, Ui.WRAP, 1f, 0, 0, dp(8), 0)
        )
        sliders.addView(
            Ui.seek(ctx, "Размер", 10, 400, (item.scale * 100).toInt(), { "$it%" }) { v ->
                Repo.mutate(ctx, id) { x -> x.scale = v / 100f }
                OverlayService.refresh(false)
            },
            Ui.lin(0, Ui.WRAP, 1f, dp(8), 0, 0, 0)
        )
        card.addView(sliders, Ui.lin(Ui.MATCH, Ui.WRAP, 0f, 0, dp(4), 0, 0))

        // Кнопки
        card.addView(
            Ui.row(
                ctx,
                Ui.chip(ctx, if (item.visible) "Скрыть" else "Показать", !item.visible) {
                    act { it.visible = !it.visible }
                },
                Ui.chip(ctx, if (item.locked) "Открепить" else "Закрепить", item.locked) {
                    act { it.locked = !it.locked }
                },
                Ui.chip(ctx, "Удалить") {
                    Repo.remove(ctx, id)
                    OverlayService.refresh(false)
                    onChange()
                }
            ),
            Ui.lin(Ui.MATCH, Ui.WRAP, 0f, 0, dp(8), 0, 0)
        )

        val second = mutableListOf<View>(
            Ui.chip(ctx, "▲ Выше") {
                Repo.move(ctx, id, +1)
                OverlayService.refresh(false)
                onChange()
            },
            Ui.chip(ctx, "▼ Ниже") {
                Repo.move(ctx, id, -1)
                OverlayService.refresh(false)
                onChange()
            }
        )
        if (item.type == Type.TEXT) {
            second.add(Ui.chip(ctx, "✎ Изменить") { onEdit(id) })
        }
        card.addView(Ui.row(ctx, *second.toTypedArray()), Ui.lin(Ui.MATCH, Ui.WRAP, 0f, 0, dp(6), 0, 0))

        if (item.type == Type.VIDEO) {
            card.addView(
                Ui.row(
                    ctx,
                    Ui.chip(ctx, if (item.playing) "⏸ Пауза" else "▶ Играть", !item.playing) {
                        act { it.playing = !it.playing }
                    },
                    Ui.chip(ctx, "🔁 Повтор", item.loop) {
                        act { it.loop = !it.loop }
                    },
                    Ui.chip(ctx, "↺ Заново") {
                        act { it.playing = true }
                        OverlayService.replay(id)
                    },
                    Ui.chip(ctx, "🔊 Звук", !item.muted) {
                        act { it.muted = !it.muted }
                    }
                ),
                Ui.lin(Ui.MATCH, Ui.WRAP, 0f, 0, dp(6), 0, 0)
            )
        }
        return card
    }
}
