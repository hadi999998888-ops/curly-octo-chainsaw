package com.loophack.app

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView

/** Создание и редактирование текста внутри приложения (из оверлея то же самое делается в меню). */
class EditorActivity : Activity() {

    private lateinit var item: Item
    private var isNew = false
    private lateinit var preview: FrameLayout

    private fun d(v: Int) = Ui.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getStringExtra("id")
        val existing = if (id != null) Repo.find(this, id) else null
        if (existing != null) {
            item = existing
        } else {
            isNew = true
            item = Item(id = Repo.newId(), type = Type.TEXT, text = "", glow = 10f)
        }
        build()
        TextEditorUi.renderPreview(this, preview, item)
    }

    private fun build() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.BLACK)

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        top.setPadding(d(16), d(14), d(16), d(6))
        top.addView(
            Ui.text(this, if (isNew) "Новый текст" else "Редактирование текста", 20f, Ui.WHITE, true),
            Ui.lin(0, Ui.WRAP, 1f)
        )
        root.addView(top)

        preview = FrameLayout(this)
        preview.background = Ui.rounded(0xFF2A2236.toInt(), d(16).toFloat(), 0x33FFFFFF, d(1))
        preview.clipChildren = true
        root.addView(preview, Ui.lin(Ui.MATCH, d(150), 0f, d(16), d(6), d(16), d(6)))

        val body = TextEditorUi.build(this, item, {}) {
            TextEditorUi.renderPreview(this, preview, item)
        }
        body.setPadding(d(16), d(4), d(16), d(16))
        val scroll = ScrollView(this)
        scroll.addView(body, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(scroll, Ui.lin(Ui.MATCH, 0, 1f))

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.setPadding(d(16), d(8), d(16), d(14))
        bar.addView(Ui.button(this, "Отмена", 1) { finish() }, Ui.lin(0, Ui.WRAP, 1f, 0, 0, d(8), 0))
        bar.addView(Ui.button(this, if (isNew) "Добавить" else "Сохранить", 0) { save() }, Ui.lin(0, Ui.WRAP, 2f))
        root.addView(bar)

        setContentView(root)
    }

    private fun save() {
        if (item.text.isBlank()) {
            Ui.toast(this, "Введите текст")
            return
        }
        if (isNew) {
            Repo.place(this, item)
            Repo.add(this, item)
        } else {
            val src = item
            Repo.mutate(this, src.id) { it.copyStyleFrom(src) }
        }
        OverlayService.refresh()
        finish()
    }
}
