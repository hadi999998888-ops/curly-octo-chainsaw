package com.loophack.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

/** Два экрана: замок (пока не перешли в канал) и одна большая кнопка СТАРТ/СТОП. Всё остальное — в оверлей-меню. */
class MainActivity : Activity() {

    private var startBtn: TextView? = null
    private var statusTv: TextView? = null
    private var mainBuilt = false
    private var pendingStart = false
    private var askedPerms = false

    private fun d(v: Int) = Ui.dp(this, v)

    override fun onResume() {
        super.onResume()
        if (!Repo.gateOpen(this)) {
            mainBuilt = false
            buildGate()
            return
        }
        if (!mainBuilt) {
            buildMain()
            mainBuilt = true
        }
        if (!askedPerms) {
            askedPerms = true
            val need = ArrayList<String>()
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) need.add(Manifest.permission.POST_NOTIFICATIONS)
            for (p in MediaAccess.permissions()) {
                if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) need.add(p)
            }
            if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 4)
        }
        if (pendingStart) {
            pendingStart = false
            if (Settings.canDrawOverlays(this)) launchService()
            else Ui.toast(this, "Разрешение не выдано")
        }
        updateAll()
    }

    private fun gateRoot(): LinearLayout {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER
        root.setBackgroundColor(Ui.BLACK)
        root.setPadding(d(28), d(28), d(28), d(28))
        root.addView(Ui.logo(this, 34), Ui.lin(d(140), d(140)))
        root.addView(
            Ui.text(this, "LOOP HACK", 30f, Ui.WHITE, true),
            Ui.lin(Ui.WRAP, Ui.WRAP, 0f, 0, d(18), 0, 0)
        )
        return root
    }

    private fun buildGate() {
        val root = gateRoot()
        val msg = Ui.text(
            this,
            "Чтобы открыть приложение, один раз перейдите в наш Telegram-канал.",
            15f, Ui.GRAY
        )
        msg.gravity = Gravity.CENTER
        root.addView(msg, Ui.lin(Ui.MATCH, Ui.WRAP, 0f, 0, d(14), 0, d(26)))
        val btn = Links.telegramButton(this) { Repo.openGate(this) }
        btn.setPadding(d(12), d(18), d(12), d(18))
        btn.textSize = 16f
        root.addView(btn, Ui.lin(Ui.MATCH, Ui.WRAP))
        setContentView(root)
    }

    private fun buildMain() {
        val root = gateRoot()
        val st = Ui.text(this, "", 13f, Ui.GRAY, true)
        statusTv = st
        root.addView(st, Ui.lin(Ui.WRAP, Ui.WRAP, 0f, 0, d(6), 0, d(28)))

        val sb = Ui.button(this, "СТАРТ", 0) { onStartStop() }
        sb.textSize = 22f
        sb.setPadding(d(12), d(26), d(12), d(26))
        startBtn = sb
        root.addView(sb, Ui.lin(Ui.MATCH, Ui.WRAP))

        val hint = Ui.text(
            this,
            "После запуска внизу экрана появится тонкая стрелка. Зажмите её и проведите вверх — откроется меню.",
            13f, Ui.GRAY
        )
        hint.gravity = Gravity.CENTER
        root.addView(hint, Ui.lin(Ui.MATCH, Ui.WRAP, 0f, 0, d(16), 0, d(24)))

        root.addView(Links.telegramButton(this).also { (it as View).alpha = 0.9f }, Ui.lin(Ui.MATCH, Ui.WRAP))
        setContentView(root)
    }

    private fun updateAll() {
        val running = OverlayService.running
        statusTv?.text = if (running) "● работает" else "○ выключено"
        startBtn?.let {
            val r = d(14).toFloat()
            if (running) {
                it.text = "СТОП"
                it.setTextColor(Ui.WHITE)
                it.background = Ui.rounded(Ui.DANGER, r)
            } else {
                it.text = "СТАРТ"
                it.setTextColor(Ui.BLACK)
                it.background = Ui.gradient(r)
            }
        }
    }

    private fun onStartStop() {
        if (OverlayService.running) {
            OverlayService.stop(this)
            Ui.toast(this, "Остановлено")
            startBtn?.postDelayed({ updateAll() }, 400)
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            AlertDialog.Builder(this)
                .setTitle("Нужно разрешение")
                .setMessage("Включите для LOOP HACK «Поверх других приложений» и вернитесь назад.")
                .setPositiveButton("Открыть настройки") { _, _ ->
                    pendingStart = true
                    startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                    )
                }
                .setNegativeButton("Отмена", null)
                .show()
            return
        }
        launchService()
    }

    private fun launchService() {
        try {
            OverlayService.start(this)
            Ui.toast(this, "Готово! Стрелка внизу экрана")
            startBtn?.postDelayed({ updateAll() }, 500)
            startBtn?.postDelayed({ moveTaskToBack(true) }, 900)
        } catch (e: Exception) {
            Ui.toast(this, "Не удалось запустить")
        }
    }
}
