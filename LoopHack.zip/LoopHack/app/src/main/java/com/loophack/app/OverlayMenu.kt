package com.loophack.app

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsets
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

private const val P_MAIN = 0
private const val P_GALLERY = 1
private const val P_MUSIC = 2
private const val P_TEXT = 3
private const val P_TRACKS = 4
private const val P_NOTIFY = 5
private const val P_MORE = 6
private const val G_AVATAR = "avatar"

/** Стрелка «вверх» для ручки. */
class ChevronView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        p.strokeWidth = h * 0.12f
        val path = Path()
        path.moveTo(w * 0.34f, h * 0.66f)
        path.lineTo(w * 0.50f, h * 0.34f)
        path.lineTo(w * 0.66f, h * 0.66f)
        canvas.drawPath(path, p)
    }
}

/**
 * Тонкая стрелка у самого нижнего края + выезжающее меню.
 * Всё настраивается прямо в оверлее (галерея, музыка, текст, уведомление) — без перехода в приложение.
 * Вертикально — шторка снизу, горизонтально — боковая панель справа.
 */
class OverlayMenu(
    private val svc: Context,
    private val wm: WindowManager,
    private val onStop: () -> Unit
) {
    private val ctx: Context = ContextThemeWrapper(svc, R.style.Theme_LoopHack)
    private val ui = Handler(Looper.getMainLooper())

    private fun d(v: Int) = Ui.dp(ctx, v)

    private val baseFlags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
    private val editFlags = baseFlags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()

    // --- ручка ---
    private val handle = FrameLayout(ctx)
    private val pill = FrameLayout(ctx)
    private val chevron = ChevronView(ctx)
    private val handleLp = WindowManager.LayoutParams(
        d(110), d(44),
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        baseFlags, PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.BOTTOM or Gravity.START }
    private var handleOn = false
    private var bob: ObjectAnimator? = null
    private var downX = 0f
    private var downY = 0f
    private var startX = 0
    private var mode = 0

    // --- меню ---
    private inner class SheetLayout : LinearLayout(ctx) {
        override fun dispatchKeyEvent(e: KeyEvent): Boolean {
            if (e.keyCode == KeyEvent.KEYCODE_BACK) {
                if (e.action == KeyEvent.ACTION_UP) handleBack()
                return true
            }
            return super.dispatchKeyEvent(e)
        }

        override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
            if (ev.actionMasked == MotionEvent.ACTION_DOWN && editing && !hitsEdit(ev)) endEditing()
            return super.dispatchTouchEvent(ev)
        }
    }

    private val sheet = SheetLayout()
    private val scroll = ScrollView(ctx)
    private val sheetLp = WindowManager.LayoutParams(
        d(400), d(400),
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        baseFlags, PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING
    }
    private lateinit var backBtn: TextView
    private lateinit var titleTv: TextView
    private var sheetOn = false
    private var open = false
    private var land = false

    // --- страницы ---
    private var page = P_MAIN
    private var mainY = 0
    private var galleryKind = Type.IMAGE

    private lateinit var topBox: LinearLayout
    private var delBtn: TextView? = null
    private lateinit var listBox: LinearLayout

    // --- текстовый редактор ---
    private var draft: Item? = null
    private var snapshot: Item? = null
    private var draftIsNew = false

    // --- клавиатура ---
    private var editing = false
    private var activeEdit: EditText? = null
    private var imeSeen = false
    private val inputs = ArrayList<EditText>()
    private val imm get() = ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager

    private var delArmed = false
    private val resetDel = Runnable { delArmed = false; delBtn?.text = "Удалить всё" }

    init {
        buildHandle()
        buildSheet()
        applyGeometry()
        applyHandle()
    }

    // ------------------------------------------------------------------ ручка

    private fun restAlpha() = Repo.handleAlpha(ctx) / 100f

    private fun buildHandle() {
        pill.background = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFFFFFFFF.toInt(), 0xFFFFFFFF.toInt())
        ).apply { cornerRadius = d(10).toFloat() }
        pill.addView(chevron, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
        handle.addView(
            pill,
            FrameLayout.LayoutParams(d(64), d(20), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
                bottomMargin = d(4)
            }
        )
        handle.setOnTouchListener { _, e -> onHandleTouch(e) }
    }

    /** Применяет положение и вид стрелки из настроек. */
    private fun applyHandle() {
        val w = Screen.w(ctx)
        handleLp.x = (Repo.handleX(ctx) * max(0, w - handleLp.width)).toInt()
        handleLp.y = d(Repo.handleY(ctx))
        pill.alpha = restAlpha()
        updateLayout(handle, handleLp, handleOn)
    }

    private fun onHandleTouch(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX
                downY = e.rawY
                startX = handleLp.x
                mode = 0
                pill.animate().scaleX(1.15f).scaleY(1.25f).alpha(1f).setDuration(110).start()
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - downX
                val dy = e.rawY - downY
                if (mode == 0) {
                    if (-dy > d(30) && abs(dy) > abs(dx)) {
                        mode = 2
                        openMenu()
                    } else if (abs(dx) > d(14) && abs(dx) > abs(dy)) {
                        mode = 1
                    }
                }
                if (mode == 1) {
                    handleLp.x = (startX + dx).toInt().coerceIn(0, max(0, Screen.w(ctx) - handleLp.width))
                    updateLayout(handle, handleLp, handleOn)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                pill.animate().scaleX(1f).scaleY(1f).alpha(restAlpha()).setDuration(160).start()
                if (mode == 1) {
                    val range = max(1, Screen.w(ctx) - handleLp.width)
                    Repo.setHandleX(ctx, handleLp.x.toFloat() / range)
                }
                mode = 0
            }
        }
        return true
    }

    private fun showHandle() {
        if (handleOn) return
        applyHandle()
        try {
            wm.addView(handle, handleLp)
            handleOn = true
        } catch (e: Exception) {
            return
        }
        bob?.cancel()
        val a = ObjectAnimator.ofFloat(chevron, "translationY", 0f, -d(2).toFloat())
        a.duration = 900
        a.repeatCount = ValueAnimator.INFINITE
        a.repeatMode = ValueAnimator.REVERSE
        a.interpolator = AccelerateDecelerateInterpolator()
        a.start()
        bob = a
    }

    private fun hideHandle() {
        bob?.cancel()
        bob = null
        chevron.translationY = 0f
        pill.animate().cancel()
        pill.scaleX = 1f
        pill.scaleY = 1f
        if (!handleOn) return
        try {
            wm.removeView(handle)
        } catch (e: Exception) {
        }
        handleOn = false
    }

    // ------------------------------------------------------------------ каркас меню

    private fun buildSheet() {
        sheet.orientation = LinearLayout.VERTICAL
        sheet.isFocusableInTouchMode = true
        sheet.setOnApplyWindowInsetsListener { v, insets ->
            if (Build.VERSION.SDK_INT >= 30) {
                val vis = insets.isVisible(WindowInsets.Type.ime())
                if (vis) {
                    imeSeen = true
                } else if (editing && imeSeen) {
                    ui.post { endEditing() }
                }
            }
            v.onApplyWindowInsets(insets)
        }

        val head = LinearLayout(ctx)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(d(10), d(10), d(12), d(6))

        backBtn = Ui.text(ctx, "‹", 26f, Ui.WHITE, true)
        backBtn.gravity = Gravity.CENTER
        backBtn.background = Ui.rounded(Ui.PANEL2, d(12).toFloat(), 0x55B8A8C8, d(1))
        backBtn.setOnClickListener { handleBack() }
        head.addView(backBtn, Ui.lin(d(40), d(40), 0f, 0, 0, d(8), 0))
        head.addView(Ui.logo(ctx, 9), Ui.lin(d(32), d(32), 0f, 0, 0, d(10), 0))
        titleTv = Ui.text(ctx, "LOOP HACK", 17f, Ui.WHITE, true)
        head.addView(titleTv, Ui.lin(0, Ui.WRAP, 1f))
        val minBtn = Ui.text(ctx, "—", 20f, Ui.WHITE, true)
        minBtn.gravity = Gravity.CENTER
        minBtn.background = Ui.rounded(Ui.PANEL2, d(12).toFloat(), 0x55B8A8C8, d(1))
        minBtn.setOnClickListener { closeMenu() }
        head.addView(minBtn, Ui.lin(d(46), d(40)))
        sheet.addView(head, Ui.lin(Ui.MATCH, Ui.WRAP))

        val line = View(ctx)
        line.setBackgroundColor(0x33FFFFFF)
        sheet.addView(line, Ui.lin(Ui.MATCH, d(2), 0f, d(16), 0, d(16), 0))

        scroll.isVerticalScrollBarEnabled = false
        scroll.overScrollMode = View.OVER_SCROLL_NEVER
        sheet.addView(scroll, Ui.lin(Ui.MATCH, 0, 1f))
    }

    /** Размер и положение меню: шторка снизу или боковая панель справа; при вводе — вверху. */
    private fun applyGeometry() {
        val w = Screen.w(ctx)
        val h = Screen.h(ctx)
        land = w > h
        if (land) {
            sheetLp.width = min(d(440), (w * 0.5f).toInt())
            sheetLp.height = ((if (editing) 0.5f else 0.94f) * h).toInt()
            sheetLp.gravity = Gravity.END or (if (editing) Gravity.TOP else Gravity.CENTER_VERTICAL)
        } else {
            sheetLp.width = min(w, d(560))
            sheetLp.height = ((if (editing) 0.45f else 0.64f) * h).toInt()
            sheetLp.gravity = Gravity.CENTER_HORIZONTAL or (if (editing) Gravity.TOP else Gravity.BOTTOM)
        }
        val r = d(26).toFloat()
        sheet.background = GradientDrawable().apply {
            setColor(0xF5080808.toInt())
            cornerRadii = if (land) floatArrayOf(r, r, 0f, 0f, 0f, 0f, r, r)
            else if (editing) floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r)
            else floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
            setStroke(d(1), 0x55FFFFFF)
        }
        updateLayout(sheet, sheetLp, sheetOn)
    }

    private fun updateLayout(v: View, lp: WindowManager.LayoutParams, on: Boolean) {
        if (!on) return
        try {
            wm.updateViewLayout(v, lp)
        } catch (e: Exception) {
        }
    }

    // ------------------------------------------------------------------ клавиатура

    /** Подключает поле к клавиатуре: окно становится фокусируемым только на время ввода. */
    private fun attachInput(et: EditText) {
        inputs.add(et)
        et.imeOptions = et.imeOptions or EditorInfo.IME_FLAG_NO_EXTRACT_UI
        et.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_DOWN) beginEditing(et)
            false
        }
        et.setOnEditorActionListener { _, a, _ ->
            if (a == EditorInfo.IME_ACTION_DONE) {
                endEditing()
                true
            } else {
                false
            }
        }
    }

    private fun beginEditing(et: EditText) {
        activeEdit = et
        if (!editing) {
            editing = true
            imeSeen = false
            sheetLp.flags = editFlags
            applyGeometry()
        }
        et.requestFocus()
        ui.postDelayed({
            if (editing && activeEdit === et) {
                imm.showSoftInput(et, 0)
                et.requestRectangleOnScreen(Rect(0, 0, et.width, et.height))
            }
        }, 140)
    }

    private fun endEditing() {
        if (!editing) return
        editing = false
        imeSeen = false
        val et = activeEdit
        activeEdit = null
        try {
            imm.hideSoftInputFromWindow(sheet.windowToken, 0)
        } catch (e: Exception) {
        }
        et?.clearFocus()
        sheet.requestFocus()
        sheetLp.flags = baseFlags
        applyGeometry()
    }

    private fun hitsEdit(ev: MotionEvent): Boolean {
        val loc = IntArray(2)
        for (et in inputs) {
            if (!et.isShown) continue
            et.getLocationOnScreen(loc)
            if (ev.rawX >= loc[0] && ev.rawX <= loc[0] + et.width &&
                ev.rawY >= loc[1] && ev.rawY <= loc[1] + et.height
            ) return true
        }
        return false
    }

    // ------------------------------------------------------------------ навигация по страницам

    private fun pageColumn(): LinearLayout {
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(d(14), d(10), d(14), d(40))
        return col
    }

    private fun put(box: LinearLayout, v: View, top: Int = 10) {
        box.addView(v, Ui.lin(Ui.MATCH, Ui.WRAP, 0f, 0, d(top), 0, 0))
    }

    private fun showPage(p: Int, animate: Boolean = true) {
        if (editing) endEditing()
        if (page == P_MAIN && scroll.childCount > 0) mainY = scroll.scrollY
        page = p
        inputs.clear()
        val v = when (p) {
            P_GALLERY -> buildGallery()
            P_MUSIC -> buildMusic()
            P_TRACKS -> buildTracks()
            P_NOTIFY -> buildNotify()
            P_MORE -> buildMore()
            P_TEXT -> buildText()
            else -> buildMain()
        }
        scroll.removeAllViews()
        scroll.addView(v, FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
        updateHeader()
        val y = if (p == P_MAIN) mainY else 0
        scroll.post { scroll.scrollTo(0, y) }
        if (animate) {
            scroll.alpha = 0f
            scroll.translationX = d(26).toFloat()
            scroll.animate().alpha(1f).translationX(0f)
                .setDuration(200).setInterpolator(DecelerateInterpolator()).start()
        }
    }

    private fun updateHeader() {
        backBtn.visibility = if (page == P_MAIN) View.GONE else View.VISIBLE
        titleTv.text = when (page) {
            P_GALLERY -> when (galleryKind) {
                Type.VIDEO -> "Видео"
                G_AVATAR -> "Аватар"
                else -> "Фото"
            }
            P_MUSIC -> "Музыка"
            P_TRACKS -> "Выбор трека"
            P_NOTIFY -> "Уведомление"
            P_MORE -> "Ещё"
            P_TEXT -> if (draftIsNew) "Новый текст" else "Текст"
            else -> "LOOP HACK"
        }
    }

    private fun goBack() {
        val up = when {
            page == P_GALLERY && galleryKind == G_AVATAR -> P_NOTIFY
            page == P_TRACKS -> P_MUSIC
            else -> P_MAIN
        }
        showPage(up)
    }

    private fun handleBack() {
        when {
            editing -> endEditing()
            page == P_TEXT -> commitText()
            page != P_MAIN -> goBack()
            else -> closeMenu()
        }
    }

    private fun openGallery(kind: String) {
        galleryKind = kind
        showPage(P_GALLERY)
    }

    // ------------------------------------------------------------------ главная страница

    private fun big(label: String, style: Int, onClick: () -> Unit): TextView {
        val b = Ui.button(ctx, label, style, onClick)
        b.textSize = 16f
        b.setPadding(d(6), d(20), d(6), d(20))
        return b
    }

    private fun tile(label: String, on: Boolean, onClick: () -> Unit): TextView {
        val t = Ui.chip(ctx, label, on, onClick)
        t.textSize = 13f
        t.setPadding(d(4), d(14), d(4), d(14))
        return t
    }

    private fun buildMain(): View {
        val col = pageColumn()
        topBox = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        listBox = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        col.addView(topBox)
        col.addView(listBox, Ui.lin(Ui.MATCH, Ui.WRAP, 0f, 0, d(20), 0, 0))
        rebuildTop()
        rebuildList()
        return col
    }

    /** Верх главной: три крупные кнопки добавления и три раздела. */
    private fun rebuildTop() {
        topBox.removeAllViews()
        put(
            topBox,
            Ui.row(
                ctx,
                big("Текст", 0) { showText(null) },
                big("Фото", 0) { openGallery(Type.IMAGE) },
                big("Видео", 0) { openGallery(Type.VIDEO) }
            ), 0
        )
        put(
            topBox,
            Ui.row(
                ctx,
                tile("♫  Музыка", Repo.musicPlay(ctx)) { showPage(P_MUSIC) },
                tile("Уведомление", Repo.notifyEnabled(ctx)) { showPage(P_NOTIFY) },
                tile("⚙  Ещё", false) { showPage(P_MORE) }
            ), 10
        )
    }

    private fun rebuildList() {
        val y = scroll.scrollY
        listBox.removeAllViews()
        val items = Repo.load(ctx)
        if (items.isEmpty()) {
            put(listBox, Ui.text(ctx, "Пока пусто. Нажмите «Текст», «Фото» или «Видео».", 13f, Ui.GRAY), 0)
        } else {
            put(listBox, Ui.sectionTitle(ctx, "НА ЭКРАНЕ (${items.size})"), 0)
            for (item in items.reversed()) {
                put(
                    listBox,
                    ItemPanel.card(ctx, item, { showText(it) }, { rebuildList() }),
                    8
                )
            }
        }
        scroll.post { scroll.scrollTo(0, y) }
    }

    private fun buildNotify(): View {
        val col = pageColumn()
        col.addView(NotifyPanel.build(ctx, { attachInput(it) }, { openGallery(G_AVATAR) }))
        return col
    }

    private fun buildMore(): View {
        val col = pageColumn()
        val items = Repo.load(ctx)
        val allLocked = items.isNotEmpty() && items.all { it.locked }
        val del = Ui.button(ctx, "Удалить всё", 2) { }
        delBtn = del
        del.setOnClickListener {
            if (!delArmed) {
                delArmed = true
                del.text = "Нажмите ещё раз"
                ui.removeCallbacks(resetDel)
                ui.postDelayed(resetDel, 3000)
            } else {
                delArmed = false
                ui.removeCallbacks(resetDel)
                Repo.clear(ctx)
                OverlayService.refresh(false)
                Ui.toast(ctx, "Всё удалено")
                goBack()
            }
        }
        put(
            col,
            Ui.row(
                ctx,
                Ui.button(ctx, if (allLocked) "Открепить всё" else "Закрепить всё", 1) {
                    Repo.mutateAll(ctx) { it.locked = !allLocked }
                    OverlayService.refresh(false)
                    showPage(P_MORE, false)
                },
                del
            ), 0
        )

        val arrow = Ui.card(ctx)
        arrow.addView(Ui.sectionTitle(ctx, "СТРЕЛКА ВНИЗУ"))
        arrow.addView(
            Ui.seek(ctx, "Высота над краем", 0, 200, Repo.handleY(ctx), { "$it dp" }) { v ->
                Repo.setHandleY(ctx, v)
                applyHandle()
            }
        )
        arrow.addView(
            Ui.seek(ctx, "Заметность", 15, 100, Repo.handleAlpha(ctx), { "$it%" }) { v ->
                Repo.setHandleAlpha(ctx, v)
                applyHandle()
            }
        )
        arrow.addView(
            Ui.chip(ctx, "Поставить по центру") {
                Repo.setHandleX(ctx, 0.5f)
                applyHandle()
            },
            Ui.lin(Ui.MATCH, Ui.WRAP, 0f, 0, d(6), 0, 0)
        )
        put(col, arrow, 12)

        val media = Ui.card(ctx)
        media.addView(
            Ui.seek(ctx, "Размер новых фото и видео", 80, 600, Repo.mediaWidth(ctx), { "$it dp" }) { v ->
                Repo.setMediaWidth(ctx, v)
            }
        )
        put(col, media, 10)

        put(col, Ui.expandable(ctx, "Как пользоваться", Help.INSTRUCTION), 12)
        put(col, Links.telegramButton(ctx), 12)
        put(col, Ui.button(ctx, "Остановить LOOP HACK", 1) { onStop() }, 10)
        return col
    }

    // ------------------------------------------------------------------ галерея и музыка

    private fun buildGallery(): View {
        val col = pageColumn()
        val kind = if (galleryKind == G_AVATAR) Type.IMAGE else galleryKind
        val hint = when (galleryKind) {
            G_AVATAR -> "Выберите фото для аватарки отправителя."
            Type.VIDEO -> "Нажмите на видео, чтобы добавить его на экран. Можно добавлять несколько."
            else -> "Нажмите на фото, чтобы добавить его на экран. Можно добавлять несколько."
        }
        col.addView(Ui.text(ctx, hint, 13f, Ui.GRAY))
        if (!MediaAccess.has(ctx, kind)) {
            put(col, MediaViews.needPermission(ctx) { Nav.requestMedia(ctx) }, 10)
        } else {
            val cell = max(d(60), (sheetLp.width - d(28) - d(18)) / 3)
            put(col, MediaViews.grid(ctx, kind, cell) { e -> pickMedia(kind, e) }, 10)
        }
        if (galleryKind != G_AVATAR) {
            put(
                col,
                Ui.chip(ctx, "Системная галерея (откроет приложение)") { Nav.pickMedia(ctx, kind) },
                12
            )
        }
        return col
    }

    private fun pickMedia(kind: String, e: MediaEntry) {
        if (galleryKind == G_AVATAR) {
            Repo.setNotifyAvatar(ctx, e.uri.toString())
            OverlayService.refreshNotifier()
            Ui.toast(ctx, "Аватар выбран")
            goBack()
            return
        }
        val item = Item(
            id = Repo.newId(),
            type = kind,
            uri = e.uri.toString(),
            name = e.title,
            baseWidth = Repo.mediaWidth(ctx).toFloat()
        )
        Repo.place(ctx, item)
        Repo.add(ctx, item)
        OverlayService.refresh(false)
        Ui.toast(ctx, "Добавлено на экран")
    }

    private fun buildMusic(): View {
        val col = pageColumn()
        col.addView(MusicPanel.build(ctx) { showPage(P_TRACKS) })
        return col
    }

    private fun buildTracks(): View {
        val col = pageColumn()
        col.addView(Ui.text(ctx, "Выберите трек для фоновой музыки. Она играет поверх игры и не глушит её звук.", 13f, Ui.GRAY))
        if (!MediaAccess.has(ctx, MediaAccess.AUDIO)) {
            put(col, MediaViews.needPermission(ctx) { Nav.requestMedia(ctx) }, 10)
        } else {
            put(
                col,
                MediaViews.audioList(ctx) { e ->
                    Repo.setMusicTrack(ctx, e.uri.toString(), e.title)
                    Repo.setMusicPlay(ctx, true)
                    OverlayService.musicSync()
                    Ui.toast(ctx, "Играет: ${e.title}")
                    goBack()
                }, 10
            )
        }
        return col
    }

    // ------------------------------------------------------------------ редактор текста

    /** id == null — новый текст (появляется на экране сразу, видно результат вживую). */
    private fun showText(id: String?) {
        if (id == null) {
            val item = Item(id = Repo.newId(), type = Type.TEXT, text = "Текст", glow = 10f)
            Repo.place(ctx, item)
            Repo.add(ctx, item)
            OverlayService.refresh(false)
            draft = item.copy()
            snapshot = null
            draftIsNew = true
        } else {
            val f = Repo.find(ctx, id) ?: return
            draft = f.copy()
            snapshot = f.copy()
            draftIsNew = false
        }
        showPage(P_TEXT)
    }

    private fun buildText(): View {
        val item = draft ?: return pageColumn()
        val col = pageColumn()
        val preview = FrameLayout(ctx)
        preview.background = Ui.rounded(0xFF2A2236.toInt(), d(14).toFloat(), 0x33FFFFFF, d(1))
        preview.clipChildren = true
        col.addView(preview, Ui.lin(Ui.MATCH, d(84)))
        TextEditorUi.renderPreview(ctx, preview, item)

        val ed = TextEditorUi.build(ctx, item, { attachInput(it) }) {
            TextEditorUi.renderPreview(ctx, preview, item)
            applyDraft()
        }
        col.addView(ed)
        col.addView(
            Ui.row(
                ctx,
                Ui.button(ctx, "Отмена", 1) { cancelText() },
                Ui.button(ctx, "Готово", 0) { commitText() }
            ),
            Ui.lin(Ui.MATCH, Ui.WRAP, 0f, 0, d(16), 0, 0)
        )
        return col
    }

    private fun applyDraft() {
        val dr = draft ?: return
        val t = dr.copy(text = dr.text.ifBlank { " " })
        Repo.mutate(ctx, dr.id) { it.copyStyleFrom(t) }
        OverlayService.refresh(false)
    }

    private fun cancelText() {
        val dr = draft
        if (dr != null) {
            if (draftIsNew) {
                Repo.remove(ctx, dr.id)
            } else {
                snapshot?.let { s -> Repo.mutate(ctx, dr.id) { it.copyStyleFrom(s) } }
            }
            OverlayService.refresh(false)
        }
        draft = null
        snapshot = null
        goBack()
    }

    private fun commitText() {
        val dr = draft
        if (dr != null && dr.text.isBlank()) {
            cancelText()
            return
        }
        draft = null
        snapshot = null
        goBack()
    }

    // ------------------------------------------------------------------ открытие и закрытие

    fun openMenu() {
        if (open) return
        open = true
        hideHandle()
        editing = false
        sheetLp.flags = baseFlags
        applyGeometry()
        page = P_MAIN
        showPage(P_MAIN, false)
        val fromX = if (land) sheetLp.width.toFloat() else 0f
        val fromY = if (land) 0f else sheetLp.height.toFloat()
        sheet.translationX = fromX
        sheet.translationY = fromY
        sheet.alpha = 0f
        try {
            wm.addView(sheet, sheetLp)
            sheetOn = true
        } catch (e: Exception) {
            open = false
            showHandle()
            return
        }
        sheet.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        sheet.animate()
            .translationX(0f).translationY(0f).alpha(1f)
            .setDuration(260)
            .setInterpolator(DecelerateInterpolator(1.6f))
            .withEndAction { sheet.setLayerType(View.LAYER_TYPE_NONE, null) }
            .start()
    }

    fun closeMenu() {
        if (!open) return
        if (page == P_TEXT) commitText()
        endEditing()
        open = false
        val toX = if (land) sheetLp.width.toFloat() else 0f
        val toY = if (land) 0f else sheetLp.height.toFloat()
        sheet.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        sheet.animate()
            .translationX(toX).translationY(toY).alpha(0f)
            .setDuration(200)
            .withEndAction {
                sheet.setLayerType(View.LAYER_TYPE_NONE, null)
                detachSheet()
                if (!open) showHandle()
            }
            .start()
    }

    private fun detachSheet() {
        if (!sheetOn) return
        try {
            wm.removeView(sheet)
        } catch (e: Exception) {
        }
        sheetOn = false
    }

    // ------------------------------------------------------------------ управление

    fun start() {
        if (!open) showHandle()
    }

    /** Обновляет открытое меню без потери прокрутки и без сброса полей ввода. */
    fun refreshIfOpen() {
        if (!(open && sheetOn) || editing) return
        when (page) {
            P_MAIN -> {
                rebuildTop()
                rebuildList()
            }
            P_TEXT, P_NOTIFY, P_MORE -> {}
            else -> showPage(page, false)
        }
    }

    /** Только список элементов (после перетаскивания на экране). */
    fun refreshItems() {
        if (open && sheetOn && page == P_MAIN && !editing) rebuildList()
    }

    fun raise() {
        try {
            if (handleOn) {
                wm.removeView(handle)
                wm.addView(handle, handleLp)
            }
            if (sheetOn) {
                wm.removeView(sheet)
                wm.addView(sheet, sheetLp)
            }
        } catch (e: Exception) {
        }
    }

    /** Поворот экрана: меню перестраивается под новую ориентацию. */
    fun relayout() {
        applyGeometry()
        applyHandle()
        if (open && sheetOn && !editing && page != P_TEXT) showPage(page, false)
    }

    fun destroy() {
        ui.removeCallbacksAndMessages(null)
        bob?.cancel()
        bob = null
        sheet.animate().cancel()
        pill.animate().cancel()
        if (editing) {
            try {
                imm.hideSoftInputFromWindow(sheet.windowToken, 0)
            } catch (e: Exception) {
            }
            editing = false
        }
        if (handleOn) {
            try {
                wm.removeView(handle)
            } catch (e: Exception) {
            }
            handleOn = false
        }
        detachSheet()
        open = false
    }
}
