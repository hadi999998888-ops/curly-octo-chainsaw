package com.loophack.app

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri

/**
 * Фоновая музыка. Живёт в сервисе, поэтому играет, пока вы в игре или в TikTok.
 * Не забирает аудиофокус: звук игры не приглушается и не ставится на паузу.
 */
class MusicPlayer(private val ctx: Context) {

    private var player: MediaPlayer? = null
    private var loadedUri = ""
    private var prepared = false

    /** Приводит плеер в соответствие с сохранёнными настройками (трек, пауза/игра, громкость, повтор). */
    fun sync() {
        val uri = Repo.musicUri(ctx)
        val want = Repo.musicPlay(ctx) && uri.isNotEmpty()
        val vol = (Repo.musicVol(ctx) / 100f).coerceIn(0f, 1f)

        if (uri != loadedUri) {
            release()
            loadedUri = uri
            if (uri.isNotEmpty()) create(uri)
        }
        val p = player ?: return
        try {
            p.isLooping = Repo.musicLoop(ctx)
            p.setVolume(vol, vol)
            if (prepared) {
                if (want && !p.isPlaying) p.start()
                else if (!want && p.isPlaying) p.pause()
            }
        } catch (e: Exception) {
        }
    }

    private fun create(uri: String) {
        try {
            val p = MediaPlayer()
            p.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            p.setDataSource(ctx, Uri.parse(uri))
            p.setOnPreparedListener {
                prepared = true
                sync()
            }
            p.setOnCompletionListener {
                if (!Repo.musicLoop(ctx)) {
                    Repo.setMusicPlay(ctx, false)
                    OverlayService.refresh()
                }
            }
            p.setOnErrorListener { _, _, _ ->
                Ui.toast(ctx, "Не удалось воспроизвести трек")
                Repo.setMusicPlay(ctx, false)
                release()
                OverlayService.refresh()
                true
            }
            prepared = false
            player = p
            p.prepareAsync()
        } catch (e: Exception) {
            Ui.toast(ctx, "Не удалось открыть трек")
            Repo.setMusicPlay(ctx, false)
            player = null
            loadedUri = ""
        }
    }

    private fun release() {
        prepared = false
        loadedUri = ""
        try {
            player?.release()
        } catch (e: Exception) {
        }
        player = null
    }

    fun destroy() {
        release()
    }
}
